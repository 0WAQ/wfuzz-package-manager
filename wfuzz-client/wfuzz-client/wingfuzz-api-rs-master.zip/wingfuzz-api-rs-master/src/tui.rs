#![allow(dead_code)]

use std::{
    io,
    io::BufRead,
    panic,
    sync::atomic::AtomicBool,
    thread,
    time::{Duration, Instant},
};

use chrono::TimeZone;
use crossterm::{
    cursor::{EnableBlinking, Show},
    event::{DisableMouseCapture, EnableMouseCapture},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::{Backend, CrosstermBackend},
    layout::{Alignment, Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    symbols,
    text::{Line, Span},
    widgets::{Axis, Block, Borders, Chart, Dataset, Paragraph, Sparkline, Tabs},
    Frame, Terminal,
};
use tui_logger::{TuiLoggerLevelOutput, TuiLoggerWidget, TuiWidgetState};

/// 是否隐藏界面（按q隐藏，按enter恢复）
static SHOULD_QUIT: AtomicBool = AtomicBool::new(false);

/// WingFuzz TUI 界面
struct Tui<'a> {
    // tab的字段名
    titles: Vec<String>,
    // 用于tab切换
    index: usize,
    // 应用名字
    project_name: String,
    // 被测模块名字
    module_name: String,
    // 本程序版本号
    version: String,
    // 平台服务器地址，即 WFUZZ_SERVER
    server: String,
    // 平台用户名
    user_name: String,
    // 技术提供者，即 WingTecher
    provider: String,
    // 画图表
    plot_data: Vec<(f64, f64)>,
    plot_data_sparkline: Vec<u64>,
    plot_data_x: f64,
    // 需要定期更新data信息
    stats: &'a crate::types::WebsocketCommandUpdateTest,

    status: String,
    job: String,
    cpu_time: String,
    start: String,
    test_case: u64,
    path: u64,
    execution: u64,
    exec_per_sec: String,
    crash: u64,
    spaces: String,
}

impl<'a> Tui<'a> {
    /// 创建新 TUI
    ///
    /// - project_name: 项目名称
    /// - user_name: 平台用户名
    /// - server: 平台服务器地址
    /// - version: 本程序版本号
    fn new(
        project_name: String,
        user_name: String,
        server: String,
        version: String,
        stats: &'a crate::types::WebsocketCommandUpdateTest,
    ) -> Tui<'a> {
        Tui {
            titles: vec![String::from("Fuzz"), String::from("Regression")],
            index: 0,
            project_name,
            server,
            user_name,
            version,
            provider: String::from("WingTecher"),
            // 数据库不显示此项
            module_name: String::from("echo"),
            plot_data: vec![(0.0, 0.0)],
            plot_data_sparkline: vec![0],
            plot_data_x: 1000.0,
            status: String::from("Not Available"),
            job: String::from("Not Available"),
            cpu_time: "0s".to_string(),
            start: String::from("0"),
            test_case: 0,
            path: 0,
            execution: 0,
            exec_per_sec: String::from(""),
            crash: 0,
            spaces: String::from(""),
            // 实际统计信息存放处
            stats,
        }
    }

    fn prettify_float(value: f64) -> String {
        let (value, suffix) = match value {
            value if value >= 1000000.0 => (value / 1000000.0, "M"),
            value if value >= 1000.0 => (value / 1000.0, "k"),
            value => (value, ""),
        };
        match value {
            value if value >= 1000.0 => {
                format!("{value}{suffix}")
            }
            value if value >= 100.0 => {
                format!("{value:.1}{suffix}")
            }
            value if value >= 10.0 => {
                format!("{value:.2}{suffix}")
            }
            value => {
                format!("{value:.3}{suffix}")
            }
        }
    }

    fn on_tick(&mut self) {
        // 定期更新tuidata信息
        self.status = if self.stats.active {
            String::from("Active")
        } else {
            String::from("Inactive")
        };
        self.job = match self.stats.running {
            crate::RunningState::NotStarted => String::from("Not Started"),
            crate::RunningState::Started => String::from("Started"),
            crate::RunningState::Stopped => String::from("Stopped"),
            crate::RunningState::NotAlive => String::from("Not Alive"),
            crate::RunningState::StoppedByRemote => String::from("Stopped by Remote"),
        };

        let cpu_time = self.stats.cpu_time;
        let mut formatted_cpu_time = String::new();
        if cpu_time >= 86400 {
            let days = cpu_time / 86400;
            formatted_cpu_time.push_str(&format!("{}d", days));
        }
        if cpu_time >= 3600 {
            let hours = (cpu_time % 86400) / 3600;
            formatted_cpu_time.push_str(&format!("{}h", hours));
        }
        if cpu_time >= 60 {
            let minutes = (cpu_time % 3600) / 60;
            formatted_cpu_time.push_str(&format!("{}m", minutes));
        }
        let seconds = cpu_time % 60;
        formatted_cpu_time.push_str(&format!("{}s", seconds));
        self.cpu_time = formatted_cpu_time;

        self.test_case = self.stats.execs_done;
        self.path = self.stats.paths_total;
        self.execution = self.stats.execs_done;

        self.exec_per_sec = Self::prettify_float(self.stats.execs_per_sec);
        self.crash = self.stats.crashes;

        self.start = chrono::Local
            .timestamp_millis_opt(self.stats.start_at.try_into().expect("time overflows"))
            .unwrap()
            .format("%F %H:%M:%S%.3f")
            .to_string();

        self.plot_data
            .push((self.stats.cpu_time as f64, self.stats.execs_per_sec));

        // 保持最大长度为200
        if self.plot_data_sparkline.len() >= 200 {
            self.plot_data_sparkline.remove(0);
        }
        self.plot_data_sparkline
            .push(self.stats.execs_per_sec as u64);

        if self.stats.cpu_time > 1000 {
            self.plot_data_x = self.stats.cpu_time as f64;
        }
    }

    pub fn next(&mut self) {
        self.index = (self.index + 1) % self.titles.len();
    }

    pub fn previous(&mut self) {
        if self.index > 0 {
            self.index -= 1;
        } else {
            self.index = self.titles.len() - 1;
        }
    }
}

/// 创建 TUI 线程，参见 [`Tui::new()`]
///
/// 注意：本函数绕过了 Rust 的借用检查器，所以需要手动保证 stats 的生命周期足够长
/// 因为 TUI 线程在进程结束前不会停止，因此 stats 所属对象应持续在程序整个生命周期
///
/// - project_name: 项目名称
/// - user_name: 平台用户名
/// - server: 平台服务器地址
/// - version: 本程序版本号
pub fn run_tui_thread<'a>(
    project_name: String,
    user_name: String,
    server: String,
    version: String,
    stats: &'a crate::types::WebsocketCommandUpdateTest,
) {
    let ptr = stats as *const crate::types::WebsocketCommandUpdateTest;
    let stats2 = unsafe { ptr.as_ref().unwrap() };
    thread::Builder::new().name("wfuzz-api-tui".to_owned()).spawn(move || -> io::Result<()> {
        // setup terminal
        enable_raw_mode()?;
        let mut stdout = io::stdout();
        execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;
        let backend = CrosstermBackend::new(stdout);
        let mut terminal = Terminal::new(backend)?;
        let mut cnt = 0;

        // Catching panics when the main thread dies
        let old_hook = panic::take_hook();
        panic::set_hook(Box::new(move |panic_info| {
            disable_raw_mode().unwrap();
            execute!(
                io::stdout(),
                LeaveAlternateScreen,
                DisableMouseCapture,
                Show,
                EnableBlinking,
            )
            .unwrap();
            old_hook(panic_info);
        }));

        // create app and run it
        // 刷新率：每 250ms 刷新一次
        let tick_rate = Duration::from_millis(250);
        let mut tui = Tui::new(project_name, user_name, server, version, stats2);
        let mut last_tick = Instant::now();

        loop {
            // to avoid initial ui glitches
            if cnt < 1 {
                drop(terminal.clear());
                cnt += 1;
            }
            terminal.draw(|f| ui(f, &mut tui))?;

            // 避免刷新过快占用 CPU
            if last_tick.elapsed() >= tick_rate {
                tui.on_tick();
                last_tick = Instant::now();
            }

            while let Ok(true) = crossterm::event::poll(Duration::ZERO) {
                // 按完 Ctrl-C，设置 SHOULD_QUIT
                let event = crossterm::event::read();
                log::trace!("crossterm event: {:?}", event);
                if let Ok(crossterm::event::Event::Key(crossterm::event::KeyEvent {
                    code: crossterm::event::KeyCode::Char('c'),
                    modifiers: crossterm::event::KeyModifiers::CONTROL,
                    kind: crossterm::event::KeyEventKind::Press,
                    state: _,
                })) = event
                {
                    SHOULD_QUIT.store(true, std::sync::atomic::Ordering::SeqCst);
                }
            }

            if SHOULD_QUIT.load(std::sync::atomic::Ordering::SeqCst) {
                // restore terminal
                disable_raw_mode()?;
                execute!(
                    terminal.backend_mut(),
                    LeaveAlternateScreen,
                    DisableMouseCapture
                )?;
                terminal.show_cursor()?;
                println!("\nPress Control-C to stop the fuzzers, otherwise press Enter to resume the visualization\n");

                let mut line = String::new();
                BufRead::read_line(&mut io::stdin().lock(), &mut line)?;

                // setup terminal
                let mut stdout = io::stdout();
                enable_raw_mode()?;
                execute!(stdout, EnterAlternateScreen, EnableMouseCapture)?;

                cnt = 0;
                SHOULD_QUIT.store(false, std::sync::atomic::Ordering::SeqCst);
            }
        }
    }).expect("TUI start failed");
}

/// 默认边框样式
fn create_block(title: &str) -> Block {
    Block::default()
        .borders(Borders::ALL)
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .title(Span::styled(
            title,
            Style::default()
                .add_modifier(Modifier::BOLD)
                .fg(Color::Rgb(255, 255, 255)),
        ))
}

/// 使用app中的数据绘制ui界面
fn ui<B: Backend>(f: &mut Frame<B>, app: &mut Tui) {
    // 初始化界面颜色和大小
    let size = f.size();
    let block = Block::default().style(Style::default().bg(Color::Black).fg(Color::White));
    f.render_widget(block, size);

    // 分区
    let (_, rows) = crossterm::terminal::size().unwrap_or((80, 24));

    // 图表的高度，目前是小于30行干脆不显示了
    let chart_rows = if rows < 30 { 0 } else { 10 };
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints(
            [
                Constraint::Length(8),
                Constraint::Length(0), // 现在不需要 fuzz/regression 的标签了，所以也是0
                Constraint::Length(3),
                Constraint::Length(chart_rows),
                Constraint::Length(6),
                Constraint::Min(0),
            ]
            .as_ref(),
        )
        .split(size);

    draw_logo(f, app, chunks[0]);
    // draw_tab(f, app, chunks[1]);
    draw_name(f, app, chunks[2]);
    draw_chart(f, app, chunks[3]);
    draw_data(f, app, chunks[4]);
    draw_log(f, app, chunks[5]);
}

/// logo和签名
fn draw_logo<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    let wfuzz_logo_new = vec![
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("    ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("███████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("   ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("███████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("███████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
        ]),
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("    ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔════╝", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("   ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║╚══", Style::default().fg(Color::LightCyan)),
            Span::styled("███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝╚══", Style::default().fg(Color::LightCyan)),
            Span::styled("███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝", Style::default().fg(Color::LightCyan)),
        ]),
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled(" █", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled(" ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("█████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("  ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("   ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("  ███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝", Style::default().fg(Color::LightCyan)),
            Span::styled("   ███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝ ", Style::default().fg(Color::LightCyan)),
        ]),
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔══╝", Style::default().fg(Color::LightCyan)),
            Span::styled("  ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled("   ██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║", Style::default().fg(Color::LightCyan)),
            Span::styled(" ███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝", Style::default().fg(Color::LightCyan)),
            Span::styled("   ███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝  ", Style::default().fg(Color::LightCyan)),
        ]),
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled("╚", Style::default().fg(Color::LightCyan)),
            Span::styled("███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔", Style::default().fg(Color::LightCyan)),
            Span::styled("███", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝", Style::default().fg(Color::LightCyan)),
            Span::styled("██", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("║     ╚", Style::default().fg(Color::LightCyan)),
            Span::styled("██████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╔╝", Style::default().fg(Color::LightCyan)),
            Span::styled("███████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
            Span::styled("███████", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled("╗", Style::default().fg(Color::LightCyan)),
        ]),
        Line::from(vec![
            Span::from(app.spaces.clone()),
            Span::styled(
                " ╚══╝╚══╝ ╚═╝      ╚═════╝ ╚══════╝╚══════╝",
                Style::default().fg(Color::LightCyan),
            ),
        ]),
    ];

    let wfuzz_sign = vec![
        Line::from(vec![
            Span::styled("    by ", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled(app.provider.clone(), Style::default().fg(Color::LightCyan)),
            Span::styled("    ", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled(
                app.version.clone(),
                Style::default().fg(Color::Rgb(255, 255, 255)),
            ),
        ]),
        Line::from(vec![Span::styled(
            " ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "    PlatForm: ",
            Style::default().fg(Color::Yellow),
        )]),
        Line::from(vec![
            Span::styled("    ", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled(
                app.server.clone(),
                Style::default().fg(Color::Rgb(255, 255, 255)),
            ),
        ]),
        Line::from(vec![Span::styled(
            "    Login as: ",
            Style::default().fg(Color::Yellow),
        )]),
        Line::from(vec![
            Span::styled("    ", Style::default().fg(Color::Rgb(255, 255, 255))),
            Span::styled(
                app.user_name.clone(),
                Style::default().fg(Color::Rgb(255, 255, 255)),
            ),
        ]),
    ];

    let logo_chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Percentage(50), Constraint::Percentage(50)].as_ref())
        .split(area);

    // 设置logo样式，可选项：wfuzz_logo_new,wfuzz_logo_null,wfuzz_logo_old,wfuzz_logo_old_null
    let text_logo = wfuzz_logo_new;
    let paragraph = Paragraph::new(text_logo.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::LEFT | Borders::TOP | Borders::BOTTOM),
        )
        .alignment(Alignment::Right);
    f.render_widget(paragraph, logo_chunks[0]);

    let paragraph = Paragraph::new(wfuzz_sign.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::RIGHT | Borders::TOP | Borders::BOTTOM),
        )
        .alignment(Alignment::Left);
    f.render_widget(paragraph, logo_chunks[1]);
}

/// regression和fuzz 标题
fn draw_tab<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    let text_tab: Vec<Line<'_>> = app
        .titles
        .iter()
        .map(|t| {
            Line::from(Span::styled(
                t.to_string(),
                Style::default().fg(Color::Yellow),
            ))
        })
        .collect();
    let tabs = Tabs::new(text_tab)
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(create_block(""))
        .select(app.index)
        .highlight_style(
            Style::default()
                .add_modifier(Modifier::BOLD)
                .fg(Color::Green)
                .bg(Color::Black),
        );
    f.render_widget(tabs, area);
}

/// app名字和module名字
fn draw_name<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    let text_name = Line::from(vec![
        Span::styled(" App: ", Style::default().fg(Color::Rgb(255, 255, 255))),
        Span::styled(
            app.project_name.clone(),
            Style::default().fg(Color::LightCyan),
        ),
        // 数据库不显示module_name
        // Span::styled(
        //     "    Module: ",
        //     Style::default().fg(Color::Rgb(255, 255, 255)),
        // ),
        // Span::styled(
        //     app.module_name.clone(),
        //     Style::default().fg(Color::LightCyan),
        // ),
    ]);
    let paragraph = Paragraph::new(text_name.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(create_block(""))
        .alignment(Alignment::Left);
    f.render_widget(paragraph, area);
}

fn draw_sparkline<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    let sparkline = Sparkline::default()
        .block(create_block(""))
        .data(&app.plot_data_sparkline)
        .style(Style::default().fg(Color::LightCyan));
    f.render_widget(sparkline, area);
}

/// 绘制chart
fn draw_chart<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    // chart
    let x_labels = vec![
        Span::styled(
            "0",
            Style::default()
                .fg(Color::LightCyan)
                .add_modifier(Modifier::BOLD),
        ),
        Span::styled(
            (app.plot_data_x).to_string(),
            Style::default()
                .fg(Color::LightCyan)
                .add_modifier(Modifier::BOLD),
        ),
    ];

    let y_labels = vec![
        Span::styled(
            "",
            Style::default()
                .fg(Color::LightCyan)
                .add_modifier(Modifier::BOLD),
        ),
        Span::styled(
            "1000",
            Style::default()
                .fg(Color::LightCyan)
                .add_modifier(Modifier::BOLD),
        ),
    ];
    let datasets = vec![Dataset::default()
        .name("data1")
        .marker(symbols::Marker::Braille)
        .style(Style::default().fg(Color::LightCyan).bg(Color::Black))
        .data(&app.plot_data)];

    let chart = Chart::new(datasets)
        .style(Style::default().bg(Color::Black))
        .block(create_block(""))
        .x_axis(
            Axis::default()
                .title(Span::styled(
                    "time/s",
                    Style::default()
                        .fg(Color::LightCyan)
                        .add_modifier(Modifier::BOLD),
                ))
                .style(Style::default().fg(Color::Rgb(255, 255, 255)))
                .labels(x_labels)
                .bounds([0.0, app.plot_data_x]),
        )
        .y_axis(
            Axis::default()
                .title(Span::styled(
                    "execs/sec",
                    Style::default()
                        .fg(Color::LightCyan)
                        .add_modifier(Modifier::BOLD),
                ))
                .style(Style::default().fg(Color::Rgb(255, 255, 255)))
                .labels(y_labels)
                .bounds([0.0, 1000.0]),
        );
    f.render_widget(chart, area);
}

/// 绘制统计数据
fn draw_data<B>(f: &mut Frame<B>, app: &mut Tui, area: Rect)
where
    B: Backend,
{
    let text_data1_1 = vec![
        Line::from(vec![Span::styled(
            "Status: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "Job: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "CPU Time: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "Start: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
    ];
    let text_data1_2 = vec![
        Line::from(vec![Span::styled(
            app.status.clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.job.clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.cpu_time.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.start.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
    ];
    let text_data2_1 = vec![
        Line::from(vec![Span::styled(
            "Test Case: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "Path: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "Execution: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            "Exec/Sec: ",
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
    ];
    let text_data2_2 = vec![
        Line::from(vec![Span::styled(
            app.test_case.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.path.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.execution.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
        Line::from(vec![Span::styled(
            app.exec_per_sec.to_string().clone(),
            Style::default().fg(Color::Rgb(255, 255, 255)),
        )]),
    ];
    let text_data3_1 = vec![Line::from(vec![Span::styled(
        "Crash: ",
        Style::default().fg(Color::Rgb(255, 255, 255)),
    )])];
    let text_data3_2 = vec![Line::from(vec![Span::styled(
        app.crash.to_string().clone(),
        Style::default().fg(Color::Rgb(255, 255, 255)),
    )])];

    let chunks = Layout::default()
        .direction(Direction::Horizontal)
        .constraints(
            [
                Constraint::Ratio(1, 3),
                Constraint::Ratio(1, 3),
                Constraint::Ratio(1, 3),
            ]
            .as_ref(),
        )
        .split(area);
    let chunk0s = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Ratio(1, 3), Constraint::Min(0)].as_ref())
        .split(chunks[0]);
    let chunk1s = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Ratio(1, 3), Constraint::Min(0)].as_ref())
        .split(chunks[1]);
    let chunk2s = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([Constraint::Ratio(1, 3), Constraint::Min(0)].as_ref())
        .split(chunks[2]);

    let paragraph1_1 = Paragraph::new(text_data1_1.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::LEFT | Borders::TOP | Borders::BOTTOM),
        )
        .alignment(Alignment::Left);
    let paragraph1_2 = Paragraph::new(text_data1_2.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::TOP | Borders::BOTTOM | Borders::RIGHT),
        )
        .alignment(Alignment::Left);
    let paragraph2_1 = Paragraph::new(text_data2_1.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::LEFT | Borders::TOP | Borders::BOTTOM),
        )
        .alignment(Alignment::Left);
    let paragraph2_2 = Paragraph::new(text_data2_2.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::TOP | Borders::BOTTOM | Borders::RIGHT),
        )
        .alignment(Alignment::Left);
    let paragraph3_1 = Paragraph::new(text_data3_1.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::LEFT | Borders::TOP | Borders::BOTTOM),
        )
        .alignment(Alignment::Left);
    let paragraph3_2 = Paragraph::new(text_data3_2.clone())
        .style(Style::default().bg(Color::Black).fg(Color::White))
        .block(
            Block::default()
                .style(Style::default().bg(Color::Black).fg(Color::White))
                .borders(Borders::TOP | Borders::BOTTOM | Borders::RIGHT),
        )
        .alignment(Alignment::Left);

    f.render_widget(paragraph1_1, chunk0s[0]);
    f.render_widget(paragraph1_2, chunk0s[1]);
    f.render_widget(paragraph2_1, chunk1s[0]);
    f.render_widget(paragraph2_2, chunk1s[1]);
    f.render_widget(paragraph3_1, chunk2s[0]);
    f.render_widget(paragraph3_2, chunk2s[1]);
}

/// 绘制log
fn draw_log<B>(f: &mut Frame<B>, _: &mut Tui, area: Rect)
where
    B: Backend,
{
    let filter_state = TuiWidgetState::new().set_default_display_level(log::LevelFilter::Debug);
    let tui_w: TuiLoggerWidget = TuiLoggerWidget::default()
        .block(create_block("log"))
        .output_separator('|')
        .output_timestamp(Some("%F %H:%M:%S%.3f".to_string()))
        .output_level(Some(TuiLoggerLevelOutput::Long))
        .output_target(false)
        .output_file(false)
        .output_line(false)
        .style(
            Style::default()
                .fg(Color::Rgb(255, 255, 255))
                .bg(Color::Black),
        )
        .state(&filter_state);
    f.render_widget(tui_w, area);
}
