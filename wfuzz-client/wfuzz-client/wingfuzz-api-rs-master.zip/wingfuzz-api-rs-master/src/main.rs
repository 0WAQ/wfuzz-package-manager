use std::{
    io::Read as _,
    process::exit,
    thread,
};

use wfuzz_api::StackFrame;
use wingfuzz_api::{
    self as wfuzz_api,
    WebsocketStopCallback,
};

pub struct Container {
    pub sql_statements: Vec<String>,
    pub stack_frames: Vec<StackFrame>,
}

#[cfg(feature = "async")]
fn main() {}

#[cfg(not(feature = "async"))]
fn main() {
    // 假设你有一个包含多对语句和堆栈的字符串
    let input_str = r#"SQL Statements:
    SELECT - ( 1004.299988 + ( 10 BETWEEN x AND ( SELECT x WHERE abs ( x ) < 16384 ) * CONCAT ( x < NULL , x = ( SELECT x FROM ( WITH x ( x ) AS ( SELECT 1 ) SELECT LEAD ( x , 3 , -1 ) OVER ( x ORDER BY x ) FROM x WINDOW x AS ( PARTITION BY x ORDER BY x ) ) AS x WHERE x >= '2009-01-01' AND x <= 'c10' ) , NULL ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT MONTHNAME ( 't32' ) FROM ( SELECT '0000-01-01' AS x UNION SELECT -796692473 ) UNION SELECT JSON_UNQUOTE ( ST_Intersects ( ST_GeomFromText ( 'POLYGON((0 0, 50 45, 40 50, 0 0))' ) , ST_GeomFromText ( 'POINT(20 20)' ) ) ) UNION SELECT 240 UNION SELECT 270 UNION SELECT 1.000000 AS x ) AS x ;
  Crash Stack: #0  0x000055556335c0a1 in oceanbase::sql::ObSelectResolver::resolve_field_list(_ParseNode const&) ()
  #1  0x000055556334ff7d in oceanbase::sql::ObSelectResolver::resolve_normal_query(_ParseNode const&) ()
  #2  0x000055556335fe17 in oceanbase::sql::ObSelectResolver::resolve(_ParseNode const&) ()
  #3  0x0000555562d287e5 in int oceanbase::sql::ObResolver::select_stmt_resolver_func<oceanbase::sql::ObSelectResolver>(oceanbase::sql::ObResolverParams&, _ParseNode const&, oceanbase::sql::ObStmt*&) ()
  #4  0x000055555a7236e5 in oceanbase::sql::ObResolver::resolve(oceanbase::sql::ObResolver::IsPrepared, _ParseNode const&, oceanbase::sql::ObStmt*&) ()
  #5  0x000055555a5834e2 in oceanbase::sql::ObSql::generate_stmt(ParseResult&, oceanbase::sql::ObPlanCacheCtx*, oceanbase::sql::ObSqlCtx&, oceanbase::common::ObIAllocator&, oceanbase::sql::ObResultSet&, oceanbase::sql::ObStmt*&, ParseResult*) ()
  #6  0x000055556073186d in oceanbase::sql::ObSql::handle_ps_prepare(oceanbase::common::ObString const&, oceanbase::sql::ObSqlCtx&, oceanbase::sql::ObResultSet&, bool) ()
  #7  0x000055556072fbfa in oceanbase::sql::ObSql::stmt_prepare(oceanbase::common::ObString const&, oceanbase::sql::ObSqlCtx&, oceanbase::sql::ObResultSet&, bool) ()
  #8  0x000055555f9027d7 in oceanbase::observer::ObMPStmtPrepare::do_process(oceanbase::sql::ObSQLSessionInfo&, bool, bool, bool&) ()
  #9  0x000055555f8ff706 in oceanbase::observer::ObMPStmtPrepare::process() ()
  #10 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #11 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #12 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #13 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #14 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #15 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #16 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT x NOT BETWEEN CONCAT ( sum ( ( SELECT 1 AS x WHERE x != -128 ) ) OVER ( ORDER BY ( SELECT sum ( max ( x ) ) OVER ( ) , 2 , 'abc' FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 EXCEPT SELECT 360 ) AS x GROUP BY ( SELECT 1 ) ORDER BY 1 ) ) , NULL ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #27 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #28 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #29 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #30 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #31 0x000055556277f0c1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #32 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #33 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #34 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #35 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #36 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #37 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #38 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #39 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #40 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #41 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #42 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #43 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #44 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #45 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #46 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #47 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #48 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #49 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #50 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #51 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #52 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #53 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #54 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT x NOT BETWEEN CONCAT ( sum ( ( SELECT 1 AS x WHERE x != -128 ) ) , NULL ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , ROUND ( -1 / POWER ( 1024 , '-9223372036854774800' ) , -7 ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + FROM_DAYS ( 1 ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN CONCAT ( sum ( ( SELECT 1 AS x WHERE x != -128 ) ) , NULL ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND x = 'user_version' + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055556277f0c1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055555a4fadea in oceanbase::sql::ObScalarAggregateOp::inner_get_next_batch(long) ()
  #31 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #32 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #33 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #34 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #35 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #36 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #37 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #38 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #39 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #40 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #41 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #42 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #43 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #44 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #45 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ; 
  Crash Stack: #0  __strnlen_sse2 () at ../sysdeps/x86_64/multiarch/../multiarch/strlen-vec.S:123
  #1  0x00007ffff7ca68d6 in __vfprintf_internal (s=s@entry=0x7fffb79c89f0, format=format@entry=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", ap=ap@entry=0x7fffb79c8c20, mode_flags=mode_flags@entry=0) at ./stdio-common/vfprintf-internal.c:1517
  #2  0x00007ffff7cb949a in __vsnprintf_internal (string=0x7fffb79e4e4d ", datum_str_:\"x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000"..., maxlen=<optimized out>, format=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", args=0x7fffb79c8c20, mode_flags=0) at ./libio/vsnprintf.c:114
  #3  0x000055555a36a472 in oceanbase::common::databuff_printf(char*, long, long&, char const*, ...) ()
  #4  0x000055555e5ebb1b in int oceanbase::common::databuff_print_kv<oceanbase::common::ObObjType, oceanbase::common::ObCollationType, unsigned int, unsigned int, unsigned int, oceanbase::common::ObTextStringIterState, oceanbase::common::ObString, void const*, int>(char*, long, long&, char const*, oceanbase::common::ObObjType const&, char const*, oceanbase::common::ObCollationType const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, oceanbase::common::ObTextStringIterState const&, char const*, oceanbase::common::ObString const&, char const*, void const* const&, char const*, int const&) ()
  #5  0x000055555e5eb719 in oceanbase::common::ObLogKV<oceanbase::common::ObTextStringIter const&, false>::print(char*, long, long&, bool) const ()
  #6  0x000055555a943033 in int oceanbase::common::ObLogger::fill_log_buffer<oceanbase::common::ObILogKV>(char*, long, long&, char const*, oceanbase::common::ObILogKV const&, oceanbase::common::ObILogKV const&) ()
  #7  0x000055555a9428f3 in void oceanbase::common::ObLogger::do_log_message<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}>(bool, char const*, int, char const*, int, char const*, bool, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #8  0x000055555a94232b in void oceanbase::common::ObLogger::log_it<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&>(char const*, int, char const*, int, char const*, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #9  0x000055555a94226a in void oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #10 0x000055555aa61257 in void oceanbase::common::OB_PRINT<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #11 0x000055555ffc9a37 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&)::{lambda(char const*)#1}::operator()(char const*) const ()
  #12 0x000055555ffa7913 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&) ()
  #13 0x00005555628efff6 in oceanbase::sql::json_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #14 0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #15 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #16 0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #17 0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #18 0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #19 0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #20 0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #21 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #22 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #23 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #24 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #25 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #26 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055556284f5c9 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #31 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #32 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #33 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #34 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #35 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #36 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #37 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #38 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #39 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #40 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #41 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #42 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #43 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #44 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #45 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #46 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #47 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #48 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #49 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #50 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #51 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #52 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #53 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #54 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #55 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
  Crash Stack: #0  __strnlen_sse2 () at ../sysdeps/x86_64/multiarch/../multiarch/strlen-vec.S:158
  #1  0x00007ffff7ca68d6 in __vfprintf_internal (s=s@entry=0x7fffb804e9f0, format=format@entry=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", ap=ap@entry=0x7fffb804ec20, mode_flags=mode_flags@entry=0) at ./stdio-common/vfprintf-internal.c:1517
  #2  0x00007ffff7cb949a in __vsnprintf_internal (string=0x7fffb806ae4d ", datum_str_:\"se, ref_expr:{item_type:\"T_REF_COLUMN\", result_type:{meta:{type:\"\", collation:\"binary\", coercibility:\"NUMERIC\"}, accuracy:{length:-1, precision:-1, scale:-1}, flag:0, calc_type:{type:\"NU"..., maxlen=<optimized out>, format=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", args=0x7fffb804ec20, mode_flags=0) at ./libio/vsnprintf.c:114
  #3  0x000055555a36a472 in oceanbase::common::databuff_printf(char*, long, long&, char const*, ...) ()
  #4  0x000055555e5ebb1b in int oceanbase::common::databuff_print_kv<oceanbase::common::ObObjType, oceanbase::common::ObCollationType, unsigned int, unsigned int, unsigned int, oceanbase::common::ObTextStringIterState, oceanbase::common::ObString, void const*, int>(char*, long, long&, char const*, oceanbase::common::ObObjType const&, char const*, oceanbase::common::ObCollationType const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, oceanbase::common::ObTextStringIterState const&, char const*, oceanbase::common::ObString const&, char const*, void const* const&, char const*, int const&) ()
  #5  0x000055555e5eb719 in oceanbase::common::ObLogKV<oceanbase::common::ObTextStringIter const&, false>::print(char*, long, long&, bool) const ()
  #6  0x000055555a943033 in int oceanbase::common::ObLogger::fill_log_buffer<oceanbase::common::ObILogKV>(char*, long, long&, char const*, oceanbase::common::ObILogKV const&, oceanbase::common::ObILogKV const&) ()
  #7  0x000055555a9428f3 in void oceanbase::common::ObLogger::do_log_message<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}>(bool, char const*, int, char const*, int, char const*, bool, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #8  0x000055555a94232b in void oceanbase::common::ObLogger::log_it<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&>(char const*, int, char const*, int, char const*, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #9  0x000055555a94226a in void oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #10 0x000055555aa61257 in void oceanbase::common::OB_PRINT<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #11 0x000055555ffc9a37 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&)::{lambda(char const*)#1}::operator()(char const*) const ()
  #12 0x000055555ffa7913 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&) ()
  #13 0x00005555628efff6 in oceanbase::sql::json_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #14 0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #15 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #16 0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #17 0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #18 0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #19 0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #20 0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #21 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #22 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #23 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #24 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #25 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #26 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055556284f5c9 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #31 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #32 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #33 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #34 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #35 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #36 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #37 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #38 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #39 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #40 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #41 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #42 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #43 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #44 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #45 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #46 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #47 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #48 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #49 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #50 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #51 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #52 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #53 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #54 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #55 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 't36' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
  Crash Stack: #0  __strnlen_sse2 () at ../sysdeps/x86_64/multiarch/../multiarch/strlen-vec.S:123
  #1  0x00007ffff7ca68d6 in __vfprintf_internal (s=s@entry=0x7fffb9acc9f0, format=format@entry=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", ap=ap@entry=0x7fffb9accc20, mode_flags=mode_flags@entry=0) at ./stdio-common/vfprintf-internal.c:1517
  #2  0x00007ffff7cb949a in __vsnprintf_internal (string=0x7fffb9ae8e4d ", datum_str_:\"x ) AND x NOT IN ( unhex ( 't36' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01"..., maxlen=<optimized out>, format=0x5555562c265f <str.16.llvm> ", %s:\"%.*s\"", args=0x7fffb9accc20, mode_flags=0) at ./libio/vsnprintf.c:114
  #3  0x000055555a36a472 in oceanbase::common::databuff_printf(char*, long, long&, char const*, ...) ()
  #4  0x000055555e5ebb1b in int oceanbase::common::databuff_print_kv<oceanbase::common::ObObjType, oceanbase::common::ObCollationType, unsigned int, unsigned int, unsigned int, oceanbase::common::ObTextStringIterState, oceanbase::common::ObString, void const*, int>(char*, long, long&, char const*, oceanbase::common::ObObjType const&, char const*, oceanbase::common::ObCollationType const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, unsigned int const&, char const*, oceanbase::common::ObTextStringIterState const&, char const*, oceanbase::common::ObString const&, char const*, void const* const&, char const*, int const&) ()
  #5  0x000055555e5eb719 in oceanbase::common::ObLogKV<oceanbase::common::ObTextStringIter const&, false>::print(char*, long, long&, bool) const ()
  #6  0x000055555a943033 in int oceanbase::common::ObLogger::fill_log_buffer<oceanbase::common::ObILogKV>(char*, long, long&, char const*, oceanbase::common::ObILogKV const&, oceanbase::common::ObILogKV const&) ()
  #7  0x000055555a9428f3 in void oceanbase::common::ObLogger::do_log_message<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}>(bool, char const*, int, char const*, int, char const*, bool, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #8  0x000055555a94232b in void oceanbase::common::ObLogger::log_it<oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&>(char const*, int, char const*, int, char const*, unsigned long, int, oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&)::{lambda(char*, long, long&)#1}&) ()
  #9  0x000055555a94226a in void oceanbase::common::ObLogger::log_message_kv<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #10 0x000055555aa61257 in void oceanbase::common::OB_PRINT<oceanbase::common::ObILogKV, oceanbase::common::ObILogKV>(char const*, int, char const*, int, char const*, unsigned long, int, char const*, char const*, oceanbase::common::ObILogKV const&&, oceanbase::common::ObILogKV const&&) ()
  #11 0x000055555ffc9a37 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&)::{lambda(char const*)#1}::operator()(char const*) const ()
  #12 0x000055555ffa7913 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&) ()
  #13 0x00005555628efff6 in oceanbase::sql::json_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #14 0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #15 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #16 0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #17 0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #18 0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #19 0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #20 0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #21 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #22 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #23 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #24 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #25 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #26 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055556284f5c9 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #31 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #32 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #33 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #34 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #35 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #36 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #37 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #38 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #39 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #40 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #41 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #42 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #43 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #44 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #45 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #46 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #47 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #48 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #49 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #50 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #51 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #52 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #53 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #54 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #55 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY + x , x ) ;
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #23 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #24 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #25 0x000055555a599672 in oceanbase::sql::ObMergeDistinctOp::inner_get_next_batch(long) ()
  #26 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #27 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #28 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #29 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #30 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #31 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #32 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #33 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #34 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #35 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #36 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #37 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #38 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #39 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #40 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #41 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #42 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT DISTINCT 'hello' NOT IN ( SELECT DATE_FORMAT ( SYSDATE ( ) , '%Y-%m-%d' ) WHERE x < '00:00:00.000000' ) FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 'abc OR abc' UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 'abc*%' + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 240 UNION SELECT 270 UNION SELECT 360 ) AS x ORDER BY x ASC , x DESC ;
    SELECT DISTINCT 'hello' NOT IN ( SELECT DATE_FORMAT ( SYSDATE ( ) , '%Y-%m-%d' ) WHERE x < '00:00:00.000000' ) FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 EXCEPT SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 'abc*%' + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 240 UNION SELECT 270 UNION SELECT 360 ) AS x ORDER BY x ASC , x DESC ;
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055556277f0c1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #31 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #32 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #33 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #34 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #35 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #36 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #37 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #38 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #39 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #40 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #41 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #42 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #43 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #44 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #45 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #46 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #47 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #48 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #49 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #50 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) x HAVING NOT ( 1 > ( x OR x ) ) = 1 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ; 
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT '70' UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT ( SUM ( ST_Intersects ( ST_GeomFromText ( 'POLYGON((0 0, 50 45, 40 50, 0 0))' ) , UNHEX ( 'POLYGON((50 5, 55 10, 0 45, 50 5))' ) ) ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ) UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 57800.000000 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ROWS BETWEEN 2 PRECEDING AND 1 PRECEDING ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE ST_GeomFromText ( 'LINESTRING(15 15, 50 50, 60 60)' ) AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
     SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT x NOT IN ( x ) AND x NOT IN ( unhex ( 'ABCxyz' ) ) AS x FROM ( SELECT 0 AS x INTERSECT SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT JSON_ARRAY ( ( '1000-01-01 00:00:00' ) ) UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , CAST ( '7890ab' AS BINARY ) ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT * FROM ( SELECT ( 'infinity' ) AS x UNION SELECT 1 UNION SELECT 3 UNION SELECT 4 UNION SELECT lpad ( '*' , 900 , '*' ) AS x ) WHERE x = 1 AND x <= 'x' ORDER BY x > RTRIM ( SPACE ( 1977444672 ) ) , 'ENABLED' DESC ) AS x ;
  Crash Stack: #0  0x00005555651fba11 in oceanbase::common::ObTextStringIter::init(unsigned int, oceanbase::sql::ObBasicSessionInfo const*, oceanbase::common::ObIAllocator*, bool) ()
  #1  0x000055555ffa78b2 in oceanbase::sql::ObTextStringHelper::read_real_string_data(oceanbase::common::ObIAllocator&, oceanbase::common::ObDatum const&, oceanbase::sql::ObDatumMeta const&, bool, oceanbase::common::ObString&) ()
  #2  0x00005555628efff6 in oceanbase::sql::json_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f5c9 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #27 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #28 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #29 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #30 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #31 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #32 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #33 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #34 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #35 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #36 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #37 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #38 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #39 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #40 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #41 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #42 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #43 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #44 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x , sum ( x ) , avg ( x ) , sum ( x + x ) , count ( * ) FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT DISTINCT concat ( 'Kate' , JSON_ARRAY ( '' , 10 , ' ' ) , '<<' ) UNION SELECT NULL + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT LPAD ( COALESCE ( NULL , CONCAT ( UNHEX ( '2009-01-01' ) % 1 ^ 1.000000 + 1 ^ 1.000000 , NULL , NULL ) ) , '[' , ' ' ) AS x UNION SELECT 300 UNION SELECT 360 ) AS x GROUP BY x <= '838:59:59' HAVING 'hello' < COUNT ( DISTINCT ( SELECT * FROM ( SELECT 1 AS x ) JOIN ( SELECT 1 , * FROM ( SELECT * FROM ( SELECT 'aabb' NOT IN ( 2 , 3 , 4 + 100 , CASE WHEN ( x >= min ( '1234' ) AND x <= 12 ) THEN 1 ELSE max ( x ) END ) FROM ( SELECT REPEAT ( 10001 , 766 ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x WHERE x = -2 OR x = 1 GROUP BY x HAVING CASE WHEN NOT max ( x ) = stddev_pop ( x ) THEN max ( x ) ELSE 1 END < 7 ) ) ) ON 1 = 1 ) , 7 ) ORDER BY x , sum ( x ) , avg ( x != '99999.99999' ) ;
    SELECT x , sum ( x ) , avg ( x ) , sum ( x + x ) , count ( * ) FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT DISTINCT concat ( 'Kate' , JSON_ARRAY ( '' , 10 , ' ' ) , '<<' ) UNION SELECT NULL + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT LPAD ( COALESCE ( NULL , CONCAT ( UNHEX ( '2009-01-01' ) % 1 ^ 1.000000 + 1 ^ 1.000000 , NULL , NULL ) ) , '[' , ' ' ) AS x UNION SELECT 300 UNION SELECT 360 ) AS x GROUP BY x <= '838:59:59' HAVING 'hello' < COUNT ( DISTINCT ( SELECT * FROM ( SELECT 1 AS x ) JOIN ( SELECT 1 , * FROM ( SELECT * FROM ( SELECT 'aabb' NOT IN ( 2 , 3 , 4 + 100 , CASE WHEN ( x >= min ( '1234' ) AND x <= 12 ) THEN 1 ELSE max ( x ) END ) FROM ( SELECT REPEAT ( 10001 , 766 ) AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x WHERE x = -2 OR x = 1 GROUP BY x HAVING CASE WHEN NOT max ( x ) = stddev_pop ( x ) THEN max ( x ) ELSE 1 END < 7 ) ) ) ON 1 = 1 ) , 7 ) ORDER BY x , sum ( x ) , avg ( x != '99999.99999' ) ;
  Crash Stack: #0  0x00005555670855a0 in oceanbase::common::DefHashFunc<oceanbase::common::DatumHashCalculator<(oceanbase::common::ObObjType)0, oceanbase::common::ObMurmurHash> >::hash_v2_batch(unsigned long*, oceanbase::common::ObDatum*, bool, oceanbase::sql::ObBitVector const&, long, unsigned long const*, bool) ()
  #1  0x000055555a90c330 in oceanbase::sql::ObHashPartInfrastructure<oceanbase::sql::ObHashPartCols, oceanbase::sql::ObHashPartStoredRow>::calc_hash_value_for_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, long, oceanbase::sql::ObBitVector const*, unsigned long*, long, unsigned long*) ()
  #2  0x00005555624b3afc in oceanbase::sql::ObAggregateProcessor::HashBasedDistinctExtraResult::insert_row_for_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, long, oceanbase::sql::ObBitVector const*, long) ()
  #3  0x00005555624ea5a2 in oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice::add_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const*, oceanbase::sql::ObAggregateProcessor::ExtraResult*, oceanbase::sql::ObAggregateProcessor::GroupConcatExtraResult*, oceanbase::sql::ObEvalCtx&) const ()
  #4  0x000055555a622606 in int oceanbase::sql::ObAggregateProcessor::inner_process_batch<oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice>(oceanbase::sql::ObAggregateProcessor::GroupRow&, oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice&, long, long) ()
  #5  0x000055555a61f2d2 in oceanbase::sql::ObMergeGroupByOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #8  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #9  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #10 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #11 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #12 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #13 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #14 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #15 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #16 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #17 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #18 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #19 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #20 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #21 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #22 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #23 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT x NOT BETWEEN 'x' AND + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 'x' AND + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ; 
    SELECT x NOT BETWEEN 'x' AND 1 + 24421 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ; 
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 FROM ( SELECT 0 AS x UNION SELECT ROUND ( 3.141593 , 2 ) UNION SELECT 120 UNION SELECT ALL CASE WHEN 'abcxyz' LIKE 'abc___' THEN 1 < TIMESTAMP ( 'eight' , 'eight' ) ELSE 0 END UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 x HAVING NOT ( 1 > ( x <= '10:22:33' AND 34 <= 33 ) ) = 1 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN + 1 + 1 + 1 + 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ; 
    SELECT x NOT BETWEEN 'x' AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'LG PKG' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #27 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #28 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #29 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #30 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #31 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #32 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #33 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #34 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #35 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #36 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #37 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #38 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #39 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #40 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #41 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #42 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #43 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #44 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT x NOT BETWEEN 'x' AND min ( timestamp ( CONCAT ( NULL , 'b' , NULL ) , 'BBB' ) ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '32767.6' ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '32767.6' ^ 1 % 1 + 1 + 1 + 1 + '32767.6' ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + MIN ( 0.900000 ) - '$[*]' - '$' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + -8385959 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ;
    SELECT x NOT BETWEEN CONCAT ( sum ( ( SELECT 1 AS x WHERE 'Ingrid' != -128 ) ) , NULL ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 * 1 + 1 AND 1 + 1 + 1 + 1 + 1 + 1 + 740.000000 / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + '123456789' + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % ( -1 + ( 10 != ROUND ( -1 / POWER ( 1024 , mod ( x , '[[0,100],[0,NULL]]' ) ) , 20 ) ) + x ) AS x , - ( x ^ x ) AS x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT POW ( 0.100000 , -1 / 0 ) UNION SELECT 180 FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT 240 UNION SELECT 270 UNION SELECT 300 UNION SELECT CONCAT ( 'a' , NULL , NULL ) ORDER BY 10 + sum ( ( SELECT CAST ( ( x ) AS DOUBLE ) ) ) OVER ( ORDER BY x ) DESC ) AS x UNION SELECT 'abc' = ( concat ( 'ABC' , GROUP_CONCAT ( '' ) ) ) UNION SELECT 270 UNION SELECT 360 ORDER BY x + x , x ) ; 
  Crash Stack: #0  0x000055556805e00d in ob_strtod ()
  #1  0x00005555628824d7 in oceanbase::sql::common_string_double(oceanbase::sql::ObExpr const&, oceanbase::common::ObObjType const&, oceanbase::common::ObCollationType const&, oceanbase::common::ObObjType const&, oceanbase::common::ObString const&, oceanbase::common::ObDatum&) ()
  #2  0x0000555562891e6d in oceanbase::sql::string_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x0000555562916d78 in oceanbase::sql::anytype_anytype_explicit(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #4  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #5  0x000055555a8f23a7 in oceanbase::sql::ObAggregateProcessor::process(oceanbase::sql::ObAggregateProcessor::GroupRow&, bool) ()
  #6  0x00005555624bb85e in oceanbase::sql::ObAggregateProcessor::prepare(oceanbase::sql::ObAggregateProcessor::GroupRow&) ()
  #7  0x000055555a8f1352 in oceanbase::sql::ObWindowFunctionOp::AggrCell::trans_self(oceanbase::sql::ObRADatumStore::StoredRow const&) ()
  #8  0x000055555a8efcdc in oceanbase::sql::ObWindowFunctionOp::compute_wf_values(oceanbase::sql::ObWindowFunctionOp::WinFuncCell const*, long&) ()
  #9  0x000055555a8ee9fb in oceanbase::sql::ObWindowFunctionOp::process_child_batch(long, oceanbase::sql::ObBatchRows const*, long&) ()
  #10 0x0000555561402fb2 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #11 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #12 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #13 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #14 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #15 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #20 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #23 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #24 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #25 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #26 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055555a4fadea in oceanbase::sql::ObScalarAggregateOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #31 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #32 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #33 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #34 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #35 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #36 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #37 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #38 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #39 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #40 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #41 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #42 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #43 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    
  SELECT * FROM ( SELECT 'main' AS col1 , 'c9' AS col2 , 9 AS col3 , 9 AS col4 UNION ALL SELECT 'main' , 'c8' , 8 IN ( CASE WHEN 1 > 5.000000 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 IN ( 'b' , + 1 + 1 + 1 + 1 + 1 , 'd' ) THEN 'true' ELSE 'false' END ) , 8 UNION ALL SELECT 'main' , RPAD ( 'm' , 16000 , 'm' ) , 7 , 7 UNION ALL SELECT 'main' , 'c6' , 6 , 6 UNION ALL SELECT 'main' , 'c5' , 5 , 5 UNION ALL SELECT 'main' , 'c4' , 4 , 4 UNION ALL SELECT 'main' , 'c3' , 3 , 3 UNION ALL SELECT 'main' , UNHEX ( 't3' ) , 2 , 2 UNION ALL SELECT 'main' , lead ( 44 ) OVER ( ORDER BY NULL ) , 1 , 1 FROM ( SELECT 1 AS x , 1.000000 ^ 1 UNION ALL SELECT 2 AS x , 4 AS x ORDER BY ASCII ( x ) + - CASE 1 WHEN 1 THEN x > 'J' WHEN 1 THEN 1 ELSE 1 / 1 END ^ 1 + 1 % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ) UNION SELECT 'main' , 'c0' , 0 , 0 ) ; 
  Crash Stack: #0  0x0000555562888d98 in oceanbase::sql::int_string(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #1  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #2  0x0000555562956fb0 in oceanbase::sql::ObExprAscii::calc_ascii_expr(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x000055555a5f1a3a in oceanbase::sql::expr_default_eval_batch_func(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #4  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #5  0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #6  0x0000555562932dfd in oceanbase::sql::ObExprAdd::add_int_uint_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #7  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #8  0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #9  0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #10 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #11 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #12 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #13 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #14 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #15 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #16 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #17 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #18 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #19 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #20 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #21 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #22 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #23 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #24 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #25 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #26 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #27 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #28 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #29 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #30 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #31 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #32 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #33 0x000055556293428d in oceanbase::sql::ObExprAdd::add_uint_int_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #34 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #35 0x000055555a3c1338 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #36 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #37 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #38 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #39 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #40 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #41 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #42 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #43 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #44 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #45 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #46 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #47 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #48 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #49 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #50 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #51 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #52 0x0000555562850101 in oceanbase::sql::ObMergeUnionOp::do_strict_distinct_vectorize(oceanbase::sql::ObOperator&, oceanbase::sql::ObChunkDatumStore::StoredRow const*, oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, long, long, oceanbase::sql::ObMergeUnionOp::UnionOpInfo&, int&, bool&) ()
  #53 0x000055556284eded in oceanbase::sql::ObMergeUnionOp::distinct_get_next_batch(long) ()
  #54 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #55 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #56 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #57 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #58 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #59 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #60 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #61 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #62 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #63 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #64 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #65 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #66 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #67 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #68 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #69 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    
  SELECT x > 0 AND NOT x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 1 AS x INTERSECT SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x UNION SELECT ALL ROUND ( '' , 5 ) UNION SELECT 3 AS x UNION SELECT ceiling ( 'inf' ) UNION SELECT 120 UNION SELECT 180 UNION SELECT 2 IN ( SUBSTR ( 'Supercalifragilisticexpialidocious' , LENGTH ( 'Supercalifragilisticexpialidocious' ) - 30 + 1 , 1 ) , TIMESTAMP ( '2038-01-09 03:14:07' ) ) UNION SELECT 270 UNION SELECT 300 UNION SELECT COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ^ 1 % 1 ^ 1 + 1 + 1 + 1 + 1 ) AS x GROUP BY x HAVING CASE WHEN NOT max ( 100000000 ) = min ( x ) THEN DECODE ( x , SUBSTRING ( 'Supercalifragilisticexpialidocious' , 1 ) ) = 2 ELSE 1 END < 7 ;
    
  SELECT x > 0 AND NOT x FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 1 AS x INTERSECT SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x UNION SELECT ALL ROUND ( '' , 5 ) UNION SELECT 3 AS x UNION SELECT ceiling ( 'inf' ) UNION SELECT 120 UNION SELECT 180 UNION SELECT 2 IN ( SUBSTR ( 'Supercalifragilisticexpialidocious' , LENGTH ( 'Supercalifragilisticexpialidocious' ) - 30 + 1 , 1 ) , TIMESTAMP ( '2038-01-09 03:14:07' ) ) UNION SELECT 270 UNION SELECT 300 UNION SELECT COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ^ 1 % 1 ^ 1 + 1 + 1 + 1 + 1 ) AS x GROUP BY x HAVING CASE WHEN NOT max ( 100000000 ) = min ( x ) THEN DECODE ( x , SUBSTRING ( 'Supercalifragilisticexpialidocious' , 1 ) ) = 2 ELSE 1 END < 7 ; 
    
  SELECT CASE x WHEN 191 THEN 'x' ELSE x END < ( -1 + ( 1 + MIN ( repeat ( ( x < 0 ) OR ( x < 0 ) , 100 ) ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 % 40 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 > x = 899 NOT IN ( x , '7' ) ) ) AND x < 'x' FROM ( SELECT 869751 AS x UNION SELECT 60 UNION SELECT ROUND ( 'english' , '	 15	 ' ) UNION SELECT 120 UNION SELECT 180 UNION SELECT 270 UNION SELECT 3.140000 * 1.000000 / sum ( NULL ) % 1 / 1 + 1 + 1 + 1 + 1 + substr ( '' , 3 , NULL ) ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT 360 ) AS x GROUP BY x HAVING CASE WHEN NOT max ( 100000000 ) = min ( x ) THEN DECODE ( x , LPAD ( GREATEST ( 'aabb' IN ( 2 , 3 , 4 + 100 , COALESCE ( 'c' , 0 ) - COALESCE ( 0 ) ) , '' ) != 11 , '[' , ' ' ) ) = 2 ELSE 1 END < 7 ; 
  Crash Stack: #0  0x00005555617a1bc9 in oceanbase::sql::ObCrypt::init(oceanbase::common::ObString&) ()
  #1  0x00005555617a4318 in oceanbase::sql::ObExprDecode::eval_decode_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #2  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #3  0x000055555a607a51 in oceanbase::sql::cast_eval_arg_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #4  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #5  0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #6  0x0000555561a36aba in oceanbase::sql::ObRelationalTCFunc<true, (oceanbase::common::ObObjTypeClass)5, (oceanbase::common::ObObjTypeClass)5, (oceanbase::common::ObCmpOp)0>::eval_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #7  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #8  0x000055555a601949 in oceanbase::sql::ObExprCase::eval_case_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #9  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #10 0x000055555a6087f2 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #11 0x00005555619e1978 in oceanbase::sql::ObRelationalTCFunc<true, (oceanbase::common::ObObjTypeClass)1, (oceanbase::common::ObObjTypeClass)1, (oceanbase::common::ObCmpOp)2>::eval_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #12 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #13 0x000055555a825af2 in oceanbase::sql::ObOperator::filter_batch_rows(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObBitVector&, long, bool&) ()
  #14 0x000055555a3c0ce6 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #16 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #17 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #18 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #19 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #20 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #23 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #24 0x000055555a3bba14 in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #25 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #26 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #27 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #28 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #29 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #30 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #31 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #32 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #33 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #34 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #35 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #36 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #37 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT x , sum ( x ) , avg ( x ) , sum ( x + x ) , count ( * ) FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT DISTINCT concat ( 'Kate' , JSON_ARRAY ( '' , 10 , ' ' ) , '<<' ) UNION SELECT RPAD ( 'x' , 22 , JSON_ARRAY ( '' > concat ( '(' , ( 11106 ) , ')' ) , 10 , ' ' ) ) / 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT 300 UNION SELECT 360 ) AS x GROUP BY 'hello' = x OR LENGTH ( x ) HAVING 'hello' < COUNT ( DISTINCT ( SELECT x , sum ( x ) , avg ( x ) , sum ( x + x ) , count ( * ) FROM ( SELECT CAST ( -1008 AS FLOAT ) AS x UNION SELECT CASE WHEN 1.000000 ^ JSON_EXTRACT ( '{"a": "dollar \\u0024 character"}' , '$.a' ) IN ( 2 , 3 , 4 , NULL ) THEN 1 ELSE 0 END UNION SELECT SPACE ( '1234' ) ) AS x WHERE x < x AND x IS NULL GROUP BY x HAVING substring ( x , 1 , ( x < x AND x IS NULL ) ) != 'PRAGMA integrity_check' ORDER BY length ( x ) DESC ) , 7 ) ORDER BY x , sum ( x ) , avg ( x != '99999.99999' ) ;
  Crash Stack: #0  0x00005555670855a0 in oceanbase::common::DefHashFunc<oceanbase::common::DatumHashCalculator<(oceanbase::common::ObObjType)0, oceanbase::common::ObMurmurHash> >::hash_v2_batch(unsigned long*, oceanbase::common::ObDatum*, bool, oceanbase::sql::ObBitVector const&, long, unsigned long const*, bool) ()
  #1  0x000055555a90c330 in oceanbase::sql::ObHashPartInfrastructure<oceanbase::sql::ObHashPartCols, oceanbase::sql::ObHashPartStoredRow>::calc_hash_value_for_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, long, oceanbase::sql::ObBitVector const*, unsigned long*, long, unsigned long*) ()
  #2  0x00005555624b3afc in oceanbase::sql::ObAggregateProcessor::HashBasedDistinctExtraResult::insert_row_for_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, long, oceanbase::sql::ObBitVector const*, long) ()
  #3  0x00005555624ea5a2 in oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice::add_batch(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const*, oceanbase::sql::ObAggregateProcessor::ExtraResult*, oceanbase::sql::ObAggregateProcessor::GroupConcatExtraResult*, oceanbase::sql::ObEvalCtx&) const ()
  #4  0x000055555a622606 in int oceanbase::sql::ObAggregateProcessor::inner_process_batch<oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice>(oceanbase::sql::ObAggregateProcessor::GroupRow&, oceanbase::sql::ObAggregateProcessor::ObBatchRowsSlice&, long, long) ()
  #5  0x000055555a61eca9 in oceanbase::sql::ObMergeGroupByOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #8  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #9  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #10 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #11 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #12 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #13 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #14 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #15 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #16 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #17 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #18 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #19 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #20 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #21 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #22 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #23 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY min ( x ) OVER ( ORDER BY x , x , x DESC , x , LEAD ( x , 3 , -1 ) OVER ( ORDER BY x ) ) ;
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY min ( x ) OVER ( ORDER BY x , x , x DESC , x , LEAD ( x , 3 , -1 ) OVER ( ORDER BY x ) ) ; 
     SELECT 2 AS x UNION SELECT 60 ORDER BY min ( x ) OVER ( ORDER BY x , x , x DESC , x , LEAD ( x , 3 , -1 ) OVER ( ORDER BY x ) ) ; 
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY min ( x ) OVER ( ORDER BY x , x , x DESC , x , LEAD ( x , '$[0].statements_executed[0].rows_examined' , -1 ) OVER ( ORDER BY x ) ) ;
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY sum ( x ) OVER ( PARTITION BY x , x ORDER BY count ( * ) OVER ( ) , x ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING ) ;
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY sum ( x ) OVER ( PARTITION BY x , x ORDER BY count ( * ) OVER ( ) , x ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING ) ; 
     SELECT 2 AS x UNION SELECT 1.100000 ORDER BY sum ( x ) OVER ( PARTITION BY x , x ORDER BY count ( * ) OVER ( ) , sum ( x ) OVER ( PARTITION BY x , x ORDER BY x , x ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING ) ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING ) ; 
  Crash Stack: #0  memcpy () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:222
  #1  0x000055555a5d7fea in oceanbase::sql::ObRADatumStore::Block::add_row(oceanbase::sql::ObRADatumStore::ShrinkBuffer&, oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObEvalCtx&, long, unsigned int, oceanbase::sql::ObRADatumStore::StoredRow**) ()
  #2  0x000055555a8eed1e in int oceanbase::sql::ObRADatumStore::add_row<true>(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObEvalCtx*, oceanbase::sql::ObRADatumStore::StoredRow**) ()
  #3  0x0000555561403816 in oceanbase::sql::ObWindowFunctionOp::RowsStore::add_row_with_index(long, oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObEvalCtx*, oceanbase::sql::ObRADatumStore::StoredRow**, bool) ()
  #4  0x0000555561403008 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #5  0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #6  0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #7  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #8  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #9  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #10 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #11 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #12 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #13 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #14 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #15 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #16 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #17 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #18 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #19 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #20 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #21 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #22 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #23 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #24 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    
  SELECT * FROM ( SELECT 'main' AS col1 , 'c9' AS col2 , 9 AS col3 , 9 AS col4 UNION ALL SELECT 'main' , 'c8' , 8 IS NULL OR x >= x , 8 FROM ( SELECT REPEAT ( 'h' , 766 ) AS x UNION ALL SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT ( 'Infinity' ) / ( 'Infinity' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x UNION SELECT 'main' , RPAD ( 'm' , 16000 , 'm' ) , 'C2C8C2C8' , 7 UNION ALL SELECT 'main' , 'c6' , 6 , 6 UNION ALL SELECT 'main' , 'c5' , 5 , 5 UNION ALL SELECT 'main' , 'c4' , 4 , 4 UNION ALL SELECT 'main' , 'c3' , 3 , 3 UNION ALL SELECT 'main' , 'c2' , 2 , SPACE ( 1048575 ) UNION ALL SELECT 'main' , 'c1' , 1 , 1 FROM ( SELECT 1 AS x , 1.000000 ^ 1 UNION ALL SELECT 2 AS x , 4 AS x ORDER BY char_length ( concat ( '*' , x , '*' , x , '*' , CASE WHEN CASE ASCII ( x ) + 32 * CASE 1 WHEN 1 THEN x > 'J' WHEN 1 THEN 1 ELSE 1 / 1 END ^ 1 + 1 % 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 WHEN 1 THEN 1 / 1 WHEN 1 THEN 1 ELSE 1 / 1 END ^ 'PROMO%%' + 1 + 1 + 1 + 1 + 1 + 1 > x THEN 1 ELSE 'FALSE' END , '*' ) ) ) UNION SELECT 'main' , 'c0' , 'q%' , 0 ) ORDER BY '3-three' ASC LIMIT 20 ; 
    SELECT * FROM ( SELECT 'main' AS col1 , 'c9' AS col2 , 9 AS col3 , 9 AS col4 UNION ALL SELECT 'main' , 'c8' , 8 IS NULL OR x >= x , 8 FROM ( SELECT REPEAT ( 'h' , 766 ) AS x UNION ALL SELECT 60 UNION SELECT 90 UNION SELECT 120 UNION SELECT 180 UNION SELECT ( 'Infinity' ) / ( 'Infinity' ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x UNION SELECT 'main' , RPAD ( 'm' , 16000 , 'm' ) , 'C2C8C2C8' , 7 UNION ALL SELECT 'main' , 'c6' , 6 , 6 UNION ALL SELECT 'main' , 'c5' , 5 , 5 UNION ALL SELECT 'main' , 'c4' , 4 , 4 UNION ALL SELECT 'main' , 'c3' , 3 , 3 UNION ALL SELECT 'main' , 'c2' , 2 , SPACE ( 1048575 ) UNION ALL SELECT 'main' , 'c1' , 1 , 1 FROM ( SELECT 1 AS x , 1.000000 ^ 1 UNION ALL SELECT 2 AS x , 4 AS x ORDER BY char_length ( concat ( '*' , x , '*' , x , '*' , CASE WHEN CASE ASCII ( x ) + 32 * CASE 1 WHEN 1 THEN x > 'J' WHEN 1 THEN 1 ELSE 1 / 1 END ^ 1 + 1 % 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 WHEN 1 THEN 1 / 1 WHEN 1 THEN 1 ELSE 1 / 1 END ^ 'PROMO%%' + 1 + 1 + 1 + 1 + 1 + 1 > x THEN 1 ELSE 'FALSE' END , '*' ) ) ) UNION SELECT 'main' , 'c0' , 'q%' , 0 ) ORDER BY '3-three' ASC LIMIT 20 ;
  Crash Stack: #0  0x0000555562888d98 in oceanbase::sql::int_string(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #1  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #2  0x00005555618e0bc7 in oceanbase::sql::ObExprConcat::eval_concat(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #4  0x00005555618c43aa in oceanbase::sql::ObExprCharLength::eval_char_length(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #5  0x000055555a5f1a3a in oceanbase::sql::expr_default_eval_batch_func(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #6  0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #7  0x000055555a3c1338 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #8  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #9  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #10 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #11 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #12 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #13 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #14 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #15 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #16 0x0000555562841870 in oceanbase::sql::ObHashUnionOp::inner_get_next_batch(long) ()
  #17 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #18 0x000055556134598e in oceanbase::sql::ObLimitOp::inner_get_next_batch(long) ()
  #19 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #20 0x000055555a3bba14 in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #21 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #22 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #23 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #24 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #25 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #26 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #27 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #28 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #29 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #30 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #31 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #32 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #33 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT rank ( ) OVER ( ) AS x FROM ( SELECT 1 AS x FROM ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x EXCEPT SELECT 55.055000 AS x UNION SELECT 3 AS x UNION SELECT 3 AS x UNION SELECT 4 AS x ORDER BY x DESC , x ASC ) UNION SELECT 1 AS x UNION SELECT 2 AS x FROM ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x UNION SELECT NULL IS NULL AS x UNION SELECT 3 AS x UNION SELECT 4 AS x ) GROUP BY NOT 69 > 'x' UNION SELECT 2 AS x UNION SELECT 3 AS x UNION SELECT 3 AS x UNION SELECT 4 AS x ) ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION SELECT 1 UNION SELECT 2 AS x UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 9801 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ; 
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT 1 AS x UNION SELECT 71 AS x UNION SELECT 2 AS x UNION SELECT 3 AS x INTERSECT SELECT 3 AS x UNION SELECT 4 AS x ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ;
  Crash Stack: #0  memcpy () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:222
  #1  0x000055555a90abca in oceanbase::sql::ObDynamicParamSetter::update_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) const ()
  #2  0x000055555a90a9a4 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&) const ()
  #3  0x000055555a90a843 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObObjParam*&) const ()
  #4  0x000055556277697f in oceanbase::sql::ObSubPlanFilterOp::prepare_rescan_params(bool, long&) ()
  #5  0x000055556277f1f1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #8  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #9  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #10 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #11 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #12 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #13 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #14 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #16 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #17 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #18 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #19 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #20 0x000055555a6c2780 in oceanbase::sql::ObHashJoinOp::get_next_right_batch() ()
  #21 0x000055555a6c15f9 in oceanbase::sql::ObHashJoinOp::read_right_operate() ()
  #22 0x000055555a6bb9fa in oceanbase::sql::ObHashJoinOp::inner_get_next_row() ()
  #23 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #24 0x000055555a697eff in oceanbase::sql::ObHashGroupByOp::load_data_batch(long) ()
  #25 0x000055555a696ebf in oceanbase::sql::ObHashGroupByOp::inner_get_next_batch(long) ()
  #26 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #27 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #28 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #31 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #32 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #33 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #34 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #35 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #36 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #37 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #38 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #39 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #40 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #41 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #42 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #43 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #44 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #45 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #46 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #47 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #48 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    
  SELECT - 1.000000 >= x IS NOT NULL = 1 AND x < 'x' FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT ALL NULL NOT IN ( 'b' , 'c' , 9.100000 ) UNION SELECT 120 UNION SELECT FROM_DAYS ( '1234' ) AS x GROUP BY x HAVING x > ( SELECT sum ( ( ( SELECT x FROM ( SELECT * FROM ( SELECT 1 NOT IN ( 2 , 3 , 4 , '' ) ) ) ) ) ) OVER ( ) ) + 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 - substr ( '' , 3 , NULL ) ^ COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + group_concat ( ( rpad ( 'बांग्लादे' , 1200 , ' ' ) ) , ST_GeomFromText ( 'POINT(20 20)' ) ) - 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT power ( 1 , -2147483648 ) UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x ;
    
  SELECT - 1.000000 >= x IS NOT NULL = 1 AND x < 'x' FROM ( SELECT 0 AS x UNION SELECT 60 UNION SELECT ALL NULL NOT IN ( 'b' , 'c' , 9.100000 ) UNION SELECT 120 UNION SELECT FROM_DAYS ( '1234' ) AS x GROUP BY x HAVING x > ( SELECT sum ( ( ( SELECT x FROM ( SELECT * FROM ( SELECT 1 NOT IN ( 2 , 3 , 4 , '' ) ) ) ) ) ) OVER ( ) ) + 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 - substr ( '' , 3 , NULL ) ^ COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + group_concat ( ( rpad ( 'बांग्लादे' , 1200 , ' ' ) ) , ST_GeomFromText ( 'POINT(20 20)' ) ) - 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT power ( 1 , -2147483648 ) UNION SELECT 270 UNION SELECT 300 UNION SELECT 360 ) AS x ; 
  Crash Stack: #0  0x00005555628c2422 in oceanbase::sql::date_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #1  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #2  0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #4  0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #5  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #6  0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #7  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #8  0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #9  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #10 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #11 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #12 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #13 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #14 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #15 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #16 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #17 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #18 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #19 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #20 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #21 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #22 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #23 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #24 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #25 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #26 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #27 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #28 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #29 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #30 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #31 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #32 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #33 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #34 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #35 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #36 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #37 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #38 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #39 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #40 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #41 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #42 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #43 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #44 0x000055556050e089 in oceanbase::sql::ObExprMinus::minus_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #45 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #46 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #47 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #48 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #49 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #50 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #51 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #52 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #53 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #54 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #55 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #56 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #57 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #58 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #59 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #60 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #61 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #62 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #63 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #64 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #65 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #66 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #67 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #68 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #69 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #70 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #71 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #72 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #73 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #74 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #75 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #76 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #77 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #78 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #79 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #80 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #81 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #82 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #83 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #84 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #85 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #86 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #87 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #88 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #89 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #90 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #91 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #92 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #93 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #94 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #95 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #96 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #97 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #98 0x0000555562948f2d in oceanbase::sql::ObExprAdd::add_number_number(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #99 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #100 0x00005555628a6264 in oceanbase::sql::number_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #101 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #102 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #103 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #104 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #105 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #106 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #107 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #108 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #109 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #110 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #111 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #112 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #113 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #114 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #115 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #116 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #117 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #118 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #119 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #120 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #121 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #122 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #123 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #124 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #125 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #126 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #127 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #128 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #129 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #130 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #131 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #132 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #133 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #134 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #135 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #136 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #137 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #138 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #139 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #140 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #141 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #142 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #143 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #144 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #145 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #146 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #147 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #148 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #149 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #150 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #151 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #152 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #153 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #154 0x0000555562946af8 in oceanbase::sql::ObExprAdd::add_double_double(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #155 0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #156 0x000055556052bd5b in oceanbase::sql::ObExprAlignDate4Cmp::eval_align_date4cmp(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #157 0x000055555a5f1a3a in oceanbase::sql::expr_default_eval_batch_func(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #158 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #159 0x000055555a608a81 in oceanbase::sql::binary_operand_batch_eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long, bool) ()
  #160 0x000055555a606ec9 in oceanbase::sql::ObRelationalTCFunc<true, (oceanbase::common::ObObjTypeClass)7, (oceanbase::common::ObObjTypeClass)7, (oceanbase::common::ObCmpOp)4>::eval_batch(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) ()
  #161 0x000055555a5efe39 in oceanbase::sql::ObExpr::do_eval_batch(oceanbase::sql::ObEvalCtx&, oceanbase::sql::ObBitVector const&, long) const ()
  #162 0x000055555a825af2 in oceanbase::sql::ObOperator::filter_batch_rows(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObBitVector&, long, bool&) ()
  #163 0x000055555a3c0ce6 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #164 0x000055556284f6e2 in oceanbase::sql::ObMergeUnionOp::all_get_next_batch(long) ()
  #165 0x0000555562852ca2 in oceanbase::sql::ObMergeUnionOp::inner_get_next_batch(long) ()
  #166 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #167 0x0000555562504f7d in oceanbase::sql::ObHashDistinctOp::build_distinct_data_for_batch(long, bool) ()
  #168 0x00005555625067b1 in oceanbase::sql::ObHashDistinctOp::do_unblock_distinct_for_batch(long) ()
  #169 0x000055556250dfdb in oceanbase::sql::ObHashDistinctOp::inner_get_next_batch(long) ()
  #170 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #171 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #172 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #173 0x000055555a3bba14 in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #174 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #175 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #176 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #177 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #178 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #179 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #180 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #181 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #182 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #183 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #184 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #185 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #186 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x INTERSECT SELECT 3 AS x INTERSECT SELECT 3 AS x UNION SELECT 4 AS x ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x FROM ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x UNION SELECT NULL IS NULL AS x UNION SELECT 3 AS x UNION SELECT 4 AS x ) GROUP BY NOT 69 > 'x' UNION SELECT 2 AS x UNION SELECT 3 AS x UNION SELECT 3 AS x UNION SELECT 4 AS x ) UNION SELECT 2 AS x UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 9801 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ;
  Crash Stack: #0  __memmove_sse2_unaligned_erms () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:383
  #1  0x000055555a90abca in oceanbase::sql::ObDynamicParamSetter::update_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) const ()
  #2  0x000055555a90a9a4 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&) const ()
  #3  0x000055555a90a843 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObObjParam*&) const ()
  #4  0x000055556277697f in oceanbase::sql::ObSubPlanFilterOp::prepare_rescan_params(bool, long&) ()
  #5  0x000055556277f1f1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #8  0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #9  0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #10 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #11 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #12 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #13 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #14 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a9085c3 in oceanbase::sql::ObNestedLoopJoinOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055555a61e763 in oceanbase::sql::ObMergeGroupByOp::inner_get_next_batch(long) ()
  #20 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #21 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #22 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #23 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #24 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #25 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #26 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #27 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #28 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #29 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #30 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #31 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #32 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #33 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #34 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT 1 AS x UNION SELECT 71 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x INTERSECT SELECT 3 AS x INTERSECT SELECT 3 AS x UNION SELECT 4 AS x ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION SELECT 1 UNION SELECT rank ( ) OVER ( ORDER BY 'MySQL' <= x = 't9' ) AS x FROM ( SELECT 1 AS x UNION SELECT '1492' AS x UNION SELECT LPAD ( COALESCE ( NULL , '' ) , ( 1 IN ( '31' , 1 ) ) , ' ' ) AS x ) WINDOW x AS ( PARTITION BY x ORDER BY x ) UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 9801 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ; 
  Crash Stack: #0  memcpy () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:222
  #1  0x000055555a90abca in oceanbase::sql::ObDynamicParamSetter::update_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) const ()
  #2  0x000055555a90a9a4 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&) const ()
  #3  0x000055555a90a843 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObObjParam*&) const ()
  #4  0x000055556277697f in oceanbase::sql::ObSubPlanFilterOp::prepare_rescan_params(bool, long&) ()
  #5  0x000055556277f1f1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #8  0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #9  0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #10 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #11 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #12 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #13 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #14 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #16 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #17 0x000055555a9085c3 in oceanbase::sql::ObNestedLoopJoinOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055555a61e763 in oceanbase::sql::ObMergeGroupByOp::inner_get_next_batch(long) ()
  #20 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #21 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #22 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #23 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #24 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #25 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #26 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #27 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #28 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #29 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #30 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #31 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #32 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #33 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #34 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT 1.100000 AS x UNION SELECT last_insert_id ( ) ORDER BY CONCAT ( CONV ( '1234' , SUM ( x ) OVER ( PARTITION BY x ORDER BY CONCAT ( CONV ( ROW_NUMBER ( ) OVER ( ) , 2.300000 , last_insert_id ( SUBSTR ( CONV ( '1234' , 16 , 10 ) , -1 , - 1.000000 ) ) ) , x ) BETWEEN 'x10' AND 'x20' RANGE BETWEEN 3 PRECEDING AND 2 PRECEDING ) , 10 ) , x >= ( 1000 ) ) BETWEEN 'x10' AND 'x20' ; 
    SELECT 1.100000 AS x UNION SELECT last_insert_id ( ) ORDER BY CONCAT ( CONV ( '1234' , SUM ( x ) OVER ( PARTITION BY x ORDER BY CONCAT ( CONV ( ROW_NUMBER ( ) OVER ( ) , 2.300000 , last_insert_id ( SUBSTR ( CONV ( '1234' , 16 , 10 ) , -1 , - 1.000000 ) ) ) , x ) BETWEEN 'x10' AND 'x20' RANGE BETWEEN 3 PRECEDING AND 2 PRECEDING ) , 10 ) , x >= ( 1000 ) ) BETWEEN 'x10' AND 'x20' ;
  Crash Stack: #0  0x000055556288ea99 in oceanbase::sql::uint_string(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #1  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #2  0x00005555618e596b in oceanbase::sql::ObExprConv::eval_conv(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #3  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #4  0x00005555618e0bc7 in oceanbase::sql::ObExprConcat::eval_concat(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #5  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #6  0x0000555561b4737a in oceanbase::sql::ObRelationalStrFunc<true, (oceanbase::common::ObCollationType)45, false, (oceanbase::common::ObCmpOp)3>::eval(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #7  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #8  0x000055555a5e05eb in oceanbase::sql::calc_and_exprN(oceanbase::sql::ObExpr const&, oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) ()
  #9  0x000055555a5dc359 in oceanbase::sql::ObExpr::eval_one_datum_of_batch(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum*&) const ()
  #10 0x000055555a8eeded in int oceanbase::sql::ObRADatumStore::add_row<true>(oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObEvalCtx*, oceanbase::sql::ObRADatumStore::StoredRow**) ()
  #11 0x0000555561403816 in oceanbase::sql::ObWindowFunctionOp::RowsStore::add_row_with_index(long, oceanbase::common::ObIArray<oceanbase::sql::ObExpr*> const&, oceanbase::sql::ObEvalCtx*, oceanbase::sql::ObRADatumStore::StoredRow**, bool) ()
  #12 0x0000555561403008 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #13 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #14 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #15 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #16 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #17 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #18 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #19 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #20 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #21 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #22 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #23 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #24 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #25 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #26 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #27 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #28 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #29 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #30 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #31 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #32 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT 1 UNION SELECT 71 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x INTERSECT SELECT 3 AS x INTERSECT SELECT 3 AS x UNION SELECT 4 AS x ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) WHERE TRIM ( x ) = 'abcde' GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ; 
  Crash Stack: #0  __memmove_sse2_unaligned_erms () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:370
  #1  0x000055555a90abca in oceanbase::sql::ObDynamicParamSetter::update_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) const ()
  #2  0x000055555a90a9a4 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&) const ()
  #3  0x000055555a90a843 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObObjParam*&) const ()
  #4  0x000055556277697f in oceanbase::sql::ObSubPlanFilterOp::prepare_rescan_params(bool, long&) ()
  #5  0x000055556277f1f1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #8  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #9  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #10 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #11 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #12 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #13 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #14 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #16 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #17 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #18 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #19 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #20 0x000055555a9085c3 in oceanbase::sql::ObNestedLoopJoinOp::inner_get_next_batch(long) ()
  #21 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #22 0x000055555a697eff in oceanbase::sql::ObHashGroupByOp::load_data_batch(long) ()
  #23 0x000055555a696ebf in oceanbase::sql::ObHashGroupByOp::inner_get_next_batch(long) ()
  #24 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #25 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #26 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #27 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #28 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #29 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #30 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #31 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #32 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #33 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #34 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #35 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #36 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #37 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #38 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #39 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #40 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #41 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #42 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #43 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #44 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #45 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #46 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81
  
  SQL Statements:
    SELECT rank ( ) OVER ( ORDER BY x = - 1 OR x > 1 AND NOT x ) AS x FROM ( SELECT 1 AS x UNION SELECT 71 AS x UNION SELECT 2 AS x UNION SELECT 1.000000 * instr ( 'abcdefg' , NULL ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 99 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 ^ 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + COUNT ( * ) + 1 + 1 + 1 + 1 + 1 + 1 + 1 AS x INTERSECT SELECT 3 AS x INTERSECT SELECT 3 AS x UNION SELECT 4 AS x ) NATURAL LEFT JOIN ( SELECT 1 AS x UNION SELECT 1 AS x UNION SELECT 2 AS x UNION SELECT 2 AS x EXCEPT SELECT SUBSTRING ( NULL , 2 , STR_TO_DATE ( '2001-01-25 04:33' , '%Y-%m-%d %H:%i' ) ) % 1 + 1 + 1 + 1 + 1 + 1 + + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 UNION SELECT JSON_VALUE ( '{"blb": "asd123"}' , '$.blb' ) AS x UNION SELECT 4 AS x ORDER BY x DESC , MAX ( ( SELECT x AS x WHERE x = - 1 OR x > 1 AND NOT x ) ) OVER ( ORDER BY x ) ) GROUP BY x HAVING avg ( repeat ( '0' , '--test' ) ) > 1 ; 
  Crash Stack: #0  __memmove_sse2_unaligned_erms () at ../sysdeps/x86_64/multiarch/memmove-vec-unaligned-erms.S:370
  #1  0x000055555a90abca in oceanbase::sql::ObDynamicParamSetter::update_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObDatum&) const ()
  #2  0x000055555a90a9a4 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&) const ()
  #3  0x000055555a90a843 in oceanbase::sql::ObDynamicParamSetter::set_dynamic_param(oceanbase::sql::ObEvalCtx&, oceanbase::common::ObObjParam*&) const ()
  #4  0x000055556277697f in oceanbase::sql::ObSubPlanFilterOp::prepare_rescan_params(bool, long&) ()
  #5  0x000055556277f1f1 in oceanbase::sql::ObSubPlanFilterOp::inner_get_next_batch(long) ()
  #6  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #7  0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #8  0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #9  0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #10 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #11 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #12 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #13 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #14 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #15 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #16 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #17 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #18 0x000055555a8ab38a in oceanbase::sql::ObSubPlanScanOp::inner_get_next_batch(long) ()
  #19 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #20 0x000055555a6c2780 in oceanbase::sql::ObHashJoinOp::get_next_right_batch() ()
  #21 0x000055555a6c15f9 in oceanbase::sql::ObHashJoinOp::read_right_operate() ()
  #22 0x000055555a6bb9fa in oceanbase::sql::ObHashJoinOp::inner_get_next_row() ()
  #23 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #24 0x000055555a697eff in oceanbase::sql::ObHashGroupByOp::load_data_batch(long) ()
  #25 0x000055555a696ebf in oceanbase::sql::ObHashGroupByOp::inner_get_next_batch(long) ()
  #26 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #27 0x000055555a4e2610 in oceanbase::sql::ObSortOp::process_sort_batch() ()
  #28 0x000055555a4a0756 in oceanbase::sql::ObSortOp::inner_get_next_batch(long) ()
  #29 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #30 0x000055555aaf38ba in oceanbase::sql::ObWindowFunctionOp::get_next_batch_from_child(long, oceanbase::sql::ObBatchRows const*&) ()
  #31 0x0000555561402eb1 in oceanbase::sql::ObWindowFunctionOp::get_next_partition(long&) ()
  #32 0x0000555561405f03 in oceanbase::sql::ObWindowFunctionOp::partial_next_batch(long) ()
  #33 0x000055555aa2fcca in oceanbase::sql::ObWindowFunctionOp::inner_get_next_batch(long) ()
  #34 0x000055555a3c0a98 in oceanbase::sql::ObOperator::get_next_batch(long, oceanbase::sql::ObBatchRows const*&) ()
  #35 0x000055555a3bbaac in oceanbase::sql::ObResultSet::get_next_row(oceanbase::common::ObNewRow const*&) ()
  #36 0x000055555a3b6bff in oceanbase::observer::ObQueryDriver::response_query_result(oceanbase::sql::ObResultSet&, bool, bool, bool&, long) ()
  #37 0x000055555a3b5d3d in oceanbase::observer::ObSyncPlanDriver::response_result(oceanbase::observer::ObMySQLResultSet&) ()
  #38 0x000055555f8d0383 in oceanbase::observer::ObMPStmtExecute::response_result(oceanbase::observer::ObMySQLResultSet&, oceanbase::sql::ObSQLSessionInfo&, bool, bool&) ()
  #39 0x000055555f8d16c3 in oceanbase::observer::ObMPStmtExecute::do_process(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #40 0x000055555f8d8d5f in oceanbase::observer::ObMPStmtExecute::do_process_single(oceanbase::sql::ObSQLSessionInfo&, oceanbase::common::Ob2DArray<oceanbase::common::ObObjParam, 2079744, oceanbase::common::ObWrapperAllocator, false, oceanbase::common::ObSEArray<oceanbase::common::ObObjParam*, 1l, oceanbase::common::ObWrapperAllocator, false> >*, bool, bool, bool&) ()
  #41 0x000055555f8dc1e0 in oceanbase::observer::ObMPStmtExecute::process() ()
  #42 0x000055555a35e201 in oceanbase::rpc::frame::ObSqlProcessor::run() ()
  #43 0x000055555a35bb17 in oceanbase::omt::ObWorkerProcessor::process(oceanbase::rpc::ObRequest&) ()
  #44 0x000055555a34b175 in oceanbase::omt::ObThWorker::worker(long&, long&, int&) ()
  #45 0x000055555fce9354 in non-virtual thunk to oceanbase::omt::ObThWorker::run(long) ()
  #46 0x000055556825cdbc in oceanbase::lib::Thread::__th_start(void*) ()
  #47 0x00007ffff7cc5ac3 in start_thread (arg=<optimized out>) at ./nptl/pthread_create.c:442
  #48 0x00007ffff7d57850 in clone3 () at ../sysdeps/unix/sysv/linux/x86_64/clone3.S:81"#; // 用实际的字符串替换这里
    let mut containers: Vec<Container> = Vec::new();
    // 使用关键词"SQL Statements:"将字符串分割成多部分
    let parts: Vec<&str> = input_str.split("SQL Statements:").collect();

    // 迭代每一对语句和堆栈
    for part in parts.iter().skip(1) {
        // 进一步处理每一部分，例如去除首尾空白字符
        let trimmed_part = part.trim();

        // 使用关键词"Crash Stack:"将每一部分分割成语句和堆栈
        let stack_parts: Vec<&str> = trimmed_part.splitn(2, "Crash Stack:").collect();
        if stack_parts.len() == 2 {
            let sql_statement = stack_parts[0].trim();
            let stack_trace = stack_parts[1].trim();

            // println!("SQL Statement: {}", sql_statement);
            let sql_statements: Vec<String> = sql_statement
                .split(';')
                .map(|s| s.trim().to_string())
                .collect();
            // println!("*******************************");
            // println!("Crash Stack: {}", stack_trace);

            // 在这里根据堆栈信息的格式使用正则表达式解析
            // 这里只是一个示例，实际情况需要根据实际输入的格式进行调整
            let stack_frames: Vec<StackFrame> = stack_trace
                .lines()
                .map(|line| {
                    // 在这里根据实际格式解析每一行堆栈信息
                    // 这里只是一个示例，实际情况需要根据实际输入的格式进行调整
                    let parts: Vec<&str> = line.trim().split_whitespace().collect();

                    // StackFrame {
                    //     binary: parts.get(0).unwrap_or(&"").to_string(),
                    //     offset: parts.get(1).unwrap_or(&"").to_string(),
                    //     file: parts.get(2).unwrap_or(&"").to_string(),
                    //     function: parts.get(3).unwrap_or(&"").to_string(),
                    //     line: parts.get(4).unwrap_or(&"0").parse().unwrap_or(0),
                    //     col: parts.get(5).unwrap_or(&"0").parse().unwrap_or(0),
                    // }
                    // for ele in parts {
                    //     print!("{}\t\t", ele);
                    // }
                    // println!("");
                    // 定义一个变量来存储左括号之前的部分
                    let mut left_part_str = parts.get(3).unwrap_or(&"").to_string();

                    // 获取索引为3的单词
                    if let Some(left_part) = parts.get(2..) {
                        left_part_str = left_part.join(" ");
                    }
                    // println!(
                    //     "{}\t{}",
                    //     left_part_str,
                    //     parts.get(1).unwrap_or(&"").to_string()
                    // );
                    StackFrame {
                        binary: left_part_str,
                        offset: "".to_string(),
                        file: "".to_string(),
                        function: parts.get(1).unwrap_or(&"").to_string(),
                        line: 0,
                        col: 0,
                    }
                })
                .collect();
            containers.push(Container {
                sql_statements,
                stack_frames,
            });
        } else {
            println!("Crash Stack not found in part: {}", trimmed_part);
        }
    }

    // 遍历并打印 Vec<Container> 的内容
    // for container in &containers {
    //     println!("SQL Statements: {:?}", container.sql_statements);
    //     println!("-------------------------------");
    //     println!("Stack Frames: {:?}", container.stack_frames);
    // }

    // exit(-1);

    // 根据环境变量调整日志等级
    let env = env_logger::Env::new()
        .filter("WFUZZ_LOG_LEVEL")
        .write_style("WFUZZ_LOG_STYLE");

    // 是否开启 TUI
    let enable_tui = false;

    if enable_tui {
        // 把 log 库的日志打印到 TUI 的状态框里面
        let drain = tui_logger::Drain::new();

        env_logger::Builder::new()
            .format(move |_buf, record|
        // patch the env-logger entry through our drain to the tui-logger
        Ok(drain.log(record)))
            .filter_level(log::LevelFilter::Info) // 默认所有模块是 INFO 输出
            .parse_env(env) // 再由环境变量覆盖
            .init();
    } else {
        // 普通的日志输出，打印到 stderr
        env_logger::Builder::new()
            .filter_level(log::LevelFilter::Info) // 默认所有模块是 INFO 输出
            .parse_env(env) // 再由环境变量覆盖
            .init();
    }

    // 全局统计信息
    let mut stats = wfuzz_api::WebsocketCommandUpdateTest {
        cycles_done: 0,
        execs_done: 0,
        execs_per_sec: 0.0,
        paths_total: 0,
        paths_total_coverage: 0.0,
        active: false,
        running: wfuzz_api::RunningState::NotStarted,
        cpu_time: 0,
        start_at: 0,
        stop_at: 0,
        update_at: 0,
        crashes: 0,
    };

    // REST 客户端建立
    let mut client = wfuzz_api::APIClient::new(
        &std::env::var("WFUZZ_SERVER").expect("Environment variable WFUZZ_SERVER not set"),
        &std::env::var("WFUZZ_TOKEN").expect("Environment variable WFUZZ_TOKEN not set"),
    );

    log::info!("\nlogin: {:?}", client.login());

    // 启动 TUI 线程
    if enable_tui {
        wfuzz_api::run_tui_thread(
            "project_name_on_ui".to_string(),
            client.get_current_user().unwrap().username,
            std::env::var("WFUZZ_SERVER").expect("Environment variable WFUZZ_SERVER not set"),
            String::from(env!["CARGO_PKG_VERSION"]),
            &stats,
        );
    }

    log::info!("\nuser_info: {:?}", client.get_current_user());

    log::info!(
        "\ncases_of_module: {:?}",
        client.get_cases_of_module(wfuzz_api::ModuleId(6), 0, 10)
    );

    // 更新全局统计信息
    stats.active = true;
    stats.running = wfuzz_api::RunningState::Started;
    stats.execs_done = 0;
    stats.execs_per_sec = 0.0;
    stats.start_at = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis()
        .try_into()
        .unwrap();
    stats.update_at = stats.start_at;

    log::info!(
        "problems_of_module: {:?}",
        client.get_problems_of_module(wfuzz_api::ModuleId(6), 0, 10)
    );

    let mut cursor = std::io::Cursor::new("test data".as_bytes());
    log::info!(
        "upload_file: {:?}",
        client.upload_file("rust-test", &mut cursor)
    );

    let test_req = wfuzz_api::CreateTestRequest {
        project_name: "wfuzz-oceanbase-test".to_string(),
        project_description: "".to_string(),
        module_name: "ob-test".to_string(),
        module_description: "".to_string(),
        vcs: "".to_string(),
        version: "1".to_string(),
        repo: "".to_string(),
        group: wingfuzz_api::TestGroupId::from(0),
        node_id: "192.168.7.112".to_string(),
        executable_path: "".to_string(),
        language: "Rust".to_string(),
        product: "db".to_string(),
        test_type: wfuzz_api::TestType::Blackbox,
        support_ubsan: false,
        support_asan: false,
        support_coverage: false,
        coverage: 0f64,
    };
    let test = client.create_test(test_req).unwrap();
    log::info!("create_test: {:?}", test);

    log::info!("Connecting websocket");
    let mut ws_client = client.create_websocket_client(
        test.id,
        WebsocketStopCallback::new(|| {
            log::info!("Stopped by remote, bye!");
            std::process::exit(0);
        }),
    );
    log::info!("Sending update_test");
    // 持续更新统计信息，注意 TUI 同步
    for i in 0..100 {
        std::thread::sleep(std::time::Duration::from_secs(1));
        stats.execs_done += 1;
        stats.cycles_done += 1;
        stats.update_at = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_millis()
            .try_into()
            .unwrap();
        // 每隔10次更新一次执行速度
        if i % 10 == 0 {
            stats.execs_per_sec =
                (stats.execs_done) as f64 / ((stats.update_at - stats.start_at) * 1000) as f64;
        }

        // 随机报告崩溃
        // 1.构建Vec<StackFrame>
        let stacks = containers[i % containers.len()].stack_frames.clone();
        let dedup_input = serde_json::to_string(&stacks)
            .expect("Failed to serailize stacks of problem to json string");
        let mut sections = Vec::new();
        // 调用栈，为空则没有
        if !stacks.is_empty() {
            sections.push(wingfuzz_api::ProblemInfoItem::Stack(
                wingfuzz_api::ProblemInfoItemStack {
                    title: String::from("调用栈"),
                    stack: stacks,
                },
            ));
        }

        let input = containers[i % containers.len()].sql_statements.clone();
        let mut upload_problem = wingfuzz_api::WebsocketUploadProblem {
            problem_type: wingfuzz_api::ProblemType::None,
            data: "".to_string(),
            pretty_display: input.clone(),
        };
        let title = String::from("服务器崩溃");

        let input_string_tmp = input.join(" ");
        let mut encoder = flate2::read::ZlibEncoder::new(
            input_string_tmp.as_bytes(),
            flate2::Compression::default(),
        );

        let mut buf: Vec<u8> = vec![];
        encoder.read_to_end(&mut buf).unwrap();

        // 用 REST 接口上传，避免截断
        let hash_result = client.upload_file("problem", &mut buf.as_slice());
        let problem_case_hash = match hash_result {
            Ok(hash) => hash,
            Err(e) => {
                log::warn!("upload problem failed by {:?}", e);
                return;
            }
        };

        upload_problem.problem_type = wingfuzz_api::ProblemType::DatabaseCrash;
        upload_problem.data = serde_json::to_string(&wingfuzz_api::ProblemInfoAny {
            sections,
            subtype: String::from("database-crash"),
            title,
        })
        .unwrap();

        let problem = wingfuzz_api::WebsocketCommandOut::Problem(
            wingfuzz_api::WebsocketCommandProblem::new_skeleton(
                problem_case_hash,
                vec![upload_problem],
                dedup_input.as_bytes(),
            ),
        );

        ws_client.send_websocket_message(problem.to_owned());

        stats.crashes += 1;
        log::info!("Sending update_test: {:?}", stats);
        let _ = ws_client
            .send_websocket_message(wingfuzz_api::WebsocketCommandOut::UpdateTest(stats.clone()));
    }
    // 正常结束测试的操作
    stats.running = wfuzz_api::RunningState::Stopped;
    stats.stop_at = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_millis()
        .try_into()
        .unwrap();
    let _ = ws_client
        .send_websocket_message(wingfuzz_api::WebsocketCommandOut::UpdateTest(stats.clone()));
    log::info!("Waiting for 10 seconds to quit demo");
    log::info!("Please press Ctrl-C to gracefully exiy");
    std::thread::sleep(std::time::Duration::from_secs(10));
}
