#[cfg(feature = "os")]
mod os;
#[cfg(feature = "virt")]
mod virt;

use std::collections::{
    HashMap,
    HashSet,
};

#[cfg(feature = "os")]
pub use os::*;
use serde::{
    Deserialize,
    Deserializer,
    Serialize,
    Serializer,
};
use serde_repr::{
    Deserialize_repr,
    Serialize_repr,
};
#[cfg(feature = "virt")]
pub use virt::*;

use crate::*;

/// POST /oauth/token 请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LoginRequest {
    /// 固定为 client_code
    pub grant_type: String,
    /// 固定为 client
    pub client_id: String,
    /// 传 WFUZZ_TOKEN
    pub code: String,
}

/// 代表查询范围
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct QueryRange {
    /// 跳过几条
    pub skip: i32,
    /// 最多查询几条
    pub limit: i32,
}

/// POST /oauth/token 返回的数据
#[allow(dead_code)]
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LoginResponse {
    #[serde(default)]
    pub error: String,

    #[serde(default)]
    pub error_description: String,

    #[serde(default)]
    pub access_token: String,

    #[serde(default)]
    pub expires_in: i32,

    #[serde(default)]
    pub refresh_token: String,

    #[serde(default)]
    pub scope: String,

    #[serde(default)]
    pub token_type: String,
}

/// GET /api/user/current 返回的数据
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct UserInfoResponse {
    pub id: i32,
    pub username: String,
}

/// 测试类型，用于 POST /api/test
///
/// 序列化为值
#[derive(Clone, Debug, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum TestType {
    Unknown = 0,
    Greybox = 1,
    Blackbox = 2,
}

/// POST /api/test 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateTestRequest {
    pub project_name: String,
    pub project_description: String,
    pub module_name: String,
    pub module_description: String,
    pub vcs: String,
    #[serde(rename = "versionCode")]
    pub version: String,
    pub repo: String,
    pub group: TestGroupId,
    #[serde(rename = "node")]
    pub node_id: String,
    pub executable_path: String,
    pub language: String,
    pub product: String,
    pub test_type: TestType,
    #[serde(rename = "ubsan", with = "IntBoolSerializer")]
    pub support_ubsan: bool,
    #[serde(rename = "asan", with = "IntBoolSerializer")]
    pub support_asan: bool,
    #[serde(with = "IntBoolSerializer")]
    pub support_coverage: bool,
    pub coverage: f64,
}

/// POST /api/coverage/getCoverage 返回的数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HashVec {
    pub code: i32,
    pub data: Vec<String>,
}

/// 覆盖率详情
#[derive(Clone, Debug, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct CoverageFileData {
    pub hash: String,             // 文件内容的SHA1SUM
    pub path: String,             // /a/b/c，从项目根目录开始的路径
    pub line_map: String,         // base64编码
    pub line_hit_map: String,     // base64编码
    pub function_map: String,     // base64编码
    pub function_hit_map: String, // base64编码
    pub branch_map: String,       // base64编码
    pub branch_hit_map: String,   // base64编码
}

// POST /api/coverage/getCoverage 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct UploadCoverageRequest {
    pub project_id: ProjectId,
    pub module_id: ModuleId,
    pub version_id: VersionId,
    pub test_group_id: TestGroupId,
    pub files: Vec<CoverageFileData>,
    pub product: String,
}

// POST /api/coverage/upload-source 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CoverageUploadSource {
    pub hash: String, /* 如果有当前文件的内容，此hash则为文件内容的SHA1SUM，exists=1。如果没有当前文件的内容则为当前文件的路径的SHA1SUM，exists=0。 */
    pub path: String, // 源代码文件路径
    pub exists: u32,  // 是否存在实际的文件,存在则为1，不存在则为0。
    pub content: String, // 如果exists=0，content可以是空字符串。content使用base64编码。
    pub product: String, // 用于区分是code还是ui
}

/// 表示一个用例的元信息
///
/// POST /api/case/{test_id}/case 请求数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PostCaseRequest {
    /// 已上传用例的哈希值
    pub hash: String,
    /// 创建时间
    #[serde(rename = "createAt")]
    pub created_at: u64,
    /// 是初始用例吗
    #[serde(rename = "initCase", with = "IntBoolSerializer", default)]
    pub is_init_case: bool,
}

/// 表示一个测试
///
/// POST /api/test 返回的数据
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Test {
    pub id: TestId,
    pub project_id: ProjectId,
    pub module_id: ModuleId,
    pub version_id: VersionId,
    pub test_group_id: TestGroupId,
}

/// GET /api/test 返回的数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TestState {
    pub id: TestId,
    pub project_id: ProjectId,
    pub module_id: ModuleId,
    pub version_id: VersionId,
    pub problem_count: i32,
    pub case_count: i32,
    pub create_by: i32,
    pub create_at: u64,
    pub update_at: u64,
    pub delete_at: u64,
    #[serde(default)]
    pub language: Option<String>,
    pub stop_at: u64,
    pub cycles_done: i32,
    pub execs_done: i32,
    pub execs_per_sec: f64,
    pub paths_total: i32,
    #[cfg(any(feature = "dk", feature = "zz"))]
    pub paths_total_coverage: f64,
    pub active: bool,
    pub running: RunningState,
    pub cpu_time: u64,
    pub test_time: u64,
    pub test_time_active_start_at: u64,
    pub node_count: i32,
    pub instance_count: i32,
    pub fuzzer_count: i32,
    pub last_executable_path: String,
    pub last_node_id: String,
    pub product: String,
    pub test_type: TestType,
    #[serde(with = "IntBoolSerializer")]
    pub support_ubsan: bool,
    #[serde(with = "IntBoolSerializer")]
    pub support_asan: bool,
    #[serde(with = "IntBoolSerializer")]
    pub support_coverage: bool,
    pub coverage: f64,
    #[cfg(feature = "dk")]
    pub seed_hash: Option<String>,
    #[cfg(feature = "dk")]
    pub model_hash: Option<String>,
}

/// POST /api/test/testGroup 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateTestGroupRequest {
    pub project_name: String,
    pub module_name: String,
    pub project_description: String,
    pub module_description: String,
    pub vcs: String,
    pub version_code: String,
    pub repo: String,
    pub language: String,
    pub product: String,
}

/// 表示一个测试组，用于remote_test
///
/// POST /api/test/testGroup 返回的数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TestGroup {
    pub id: TestGroupId,
    pub project_id: ProjectId,
    pub module_id: ModuleId,
    pub version_id: VersionId,
}

/// 表示一个AI测试
///
/// POST /api/ai/test 返回的数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AiTest {
    /// ai测试id
    pub id: AiTestId,
    /// ai测试创建人id
    pub create_by: AiTestCreateId,
    /// ai测试模型id
    pub model_id: AiTestModelId,
    /// ai测试数据集id
    pub dataset_id: AiTestDatasetId,
    /// 模型名字
    pub model_name: String,
    /// 数据集名字
    pub dataset_name: String,
    /// 批量大小
    pub batch_size: i32,
    /// 覆盖率指标
    pub criterion: Vec<String>,
    /// 数据量
    pub data_size: i32,
    /// 测试开始时间 单位毫秒
    pub start_at: i64,
    /// 测试状态
    pub state: AiTestStateEnum,
}

/// AI测试的返回结果
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AiTestResult {
    // NC覆盖率
    pub coverage: Option<String>,
    // 层覆盖率
    pub layer_coverage: Option<Vec<LayerCoverage>>,
    // 批覆盖率
    pub batch_coverage: Option<HashMap<String, Vec<String>>>,
    // 日志
    pub log: Option<String>,
    // 其他指标
    pub feature: Option<AiFeature>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LayerCoverage {
    name: String,
    value: String,
    length: i32,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AiTestState {
    pub state: AiTestStateEnum,
}

#[derive(Clone, Debug, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum AiTestStateEnum {
    /// 未开始
    NotStarted,
    /// 开始
    Started,
    /// 完成
    Finished,
    /// 出错
    Error,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AiFeature {
    // 是否收敛
    pub not_converge: bool,
    // 损失函数是否稳定
    pub unstable_loss: bool,
    // 是否存在nan loss
    pub nan_loss: f64,
    // test acc and train acc has big gap
    pub test_not_well: f64,
    //  测试损失函数是否上升（loss越低越好)
    pub test_turn_bad: f64,
    // 准确率是否符合要求（要求为传入阈值）
    pub sc_accuracy: bool,
    // 是否存在无效relu激活
    pub died_relu: bool,
    // 梯度弥散
    pub vanish_gradient: bool,
    //  梯度爆炸
    pub explode_gradient: bool,
    // 梯度为nan
    pub nan_gradient: bool,
    // 模型是否存在过大的参数
    pub large_weight: f64,
    // 模型是否存在nan的参数
    pub nan_weight: bool,
    // 是否存在nan的loss
    pub nan_acc: f64,
    // top 3 准确率
    pub top_3: f64,
    // top 5 准确率
    pub top_5: f64,
    // auc score
    pub auc: f64,
    // 训练集的loss
    pub loss: f64,
    // 训练集的准确率
    pub acc: f64,
    // 测试集的loss
    pub val_loss: f64,
    // 测试集的准确率
    pub val_acc: f64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TargetType {
    None,
    Image,
    Elf,
}

fn number_to_target_type<'de, D>(deserializer: D) -> Result<TargetType, D::Error>
where
    D: Deserializer<'de>,
{
    let num = i32::deserialize(deserializer)?;

    let res = match num {
        1 => TargetType::Image,
        2 => TargetType::Elf,
        _ => TargetType::None,
    };

    Ok(res)
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ExecutionTaskType {
    None,
    Analysis,
    Run,
}

fn number_to_execution_task_type<'de, D>(deserializer: D) -> Result<ExecutionTaskType, D::Error>
where
    D: Deserializer<'de>,
{
    let num = i32::deserialize(deserializer)?;

    let res = match num {
        1 => ExecutionTaskType::Analysis,
        2 => ExecutionTaskType::Run,
        _ => ExecutionTaskType::None,
    };

    Ok(res)
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TaskState {
    None,
    Starting,
    Running,
    Failed,
    Success,
    Cancelled,
}

fn task_state_to_number<S>(state: &TaskState, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let num = match state {
        TaskState::Starting => 1,
        TaskState::Running => 2,
        TaskState::Failed => 3,
        TaskState::Success => 4,
        TaskState::Cancelled => 5,
        TaskState::None => 0,
    };

    num.serialize(serializer)
}

fn number_to_task_state<'de, D>(deserializer: D) -> Result<TaskState, D::Error>
where
    D: Deserializer<'de>,
{
    let num = i32::deserialize(deserializer)?;

    let res = match num {
        1 => TaskState::Starting,
        2 => TaskState::Running,
        3 => TaskState::Failed,
        4 => TaskState::Success,
        5 => TaskState::Cancelled,
        _ => TaskState::None,
    };

    Ok(res)
}

#[derive(Clone, Debug, Default, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum FileType {
    #[default]
    Unknown = 0,
    ElfBin = 1,
    DotnetDll = 2,
    JavaJar = 3,
    ProjectDir = 4,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FuzzTaskConfig {
    #[serde(default)]
    pub map_size: u32,
    #[serde(default)]
    pub variants: HashSet<String>,
    #[serde(default)]
    pub language: String,
    #[serde(default)]
    pub product: String,
    #[serde(default)]
    pub project: String,
    #[serde(default)]
    pub module: String,
    #[serde(default)]
    pub version: String,
    #[serde(default)]
    pub entrypoint: String,
    #[serde(default)]
    pub entrypoints: Vec<String>,
    #[serde(default)]
    pub r#type: FileType,
    #[serde(default)]
    pub binary: String,
    #[serde(default)]
    pub libraries: Vec<String>,
    #[serde(default)]
    pub extract: bool,
    #[serde(default)]
    pub has_source_code: bool,
    #[serde(default)]
    pub workspace: String,
}

fn string_to_fuzz_task_config<'de, D>(deserializer: D) -> Result<Option<FuzzTaskConfig>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let s: &str = serde::Deserialize::deserialize(deserializer)?;
    Ok(serde_json::from_str(s).ok())
}

/// POST /api/test/createFuzzTask 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateFuzzTaskRequest {
    pub target: String,
    pub target_type: TargetType,
    pub project_id: ProjectId,
    pub module_id: ModuleId,
    pub test_group_id: TestGroupId,
    pub entrypoint: String,
    pub arch: String,
    pub fuzz_cpu_count: i32,
    pub fuzz_minutes: i32,
    pub priority: i32,
}

/// POST /api/test/createExecutionTask 的请求数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CreateExecutionTaskRequest {
    pub target: String,
    pub target_type: TargetType,
    pub r#type: ExecutionTaskType,
    pub arguments: String,
    pub execution_cpu_count: i32,
    pub arch: String,
    pub priority: i32,
}

/// GET /api/fuzzTask/getExecutionTask/ 的返回数据
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ExecutionTaskInfo {
    pub id: ExecutionTaskId,
    #[serde(deserialize_with = "number_to_task_state")]
    pub state: TaskState,
    pub file: String,
    #[serde(deserialize_with = "number_to_target_type")]
    pub file_type: TargetType,
    #[serde(deserialize_with = "number_to_execution_task_type")]
    pub r#type: ExecutionTaskType,
    pub arguments: String,
    pub execution_cpu_count: i32,
    pub arch: String,
    pub priority: i32,
    #[serde(deserialize_with = "string_to_fuzz_task_config")]
    pub result: Option<FuzzTaskConfig>,
    pub task_runner_id: TaskRunnerId,
    pub create_at: u64,
    pub create_by: i32,
    pub update_at: u64,
    pub update_by: i32,
    pub keep_alive: i32,
    pub owner_id: String,
}

/// 表示一个测试用例
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TestCase {
    pub id: TestCaseId,
    pub file: String,
}

/// 运行状态
#[derive(Clone, Debug, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum RunningState {
    /// 未开始
    NotStarted = 0,
    /// 运行中
    Started = 1,
    /// 已停止
    Stopped = 2,
    /// 不活跃
    NotAlive = 4,
    /// 被平台停止
    StoppedByRemote = 8,
}

/// 问题类型
#[derive(Clone, Debug, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum ProblemType {
    None = 0,
    Unknown = 1,
    Timeout = 2,
    Memory = 3,
    UndefinedBehavior = 4,
    AssertError = 5,
    UncaughtExceptionError = 6,
    Other = 7,
    /// 旧版数据库模糊测试使用的类型，对应 [`ProblemInfoAny`]，现不应使用
    Any = 8,
    GoRuntimeError = 9,
    /// 数据库崩溃类型，对应 [`ProblemInfoAny`]
    DatabaseCrash = 10,
    /// 数据库逻辑错误类型，对应 [`ProblemInfoAny`]
    LogicError = 11,
}

impl From<u8> for ProblemType {
    fn from(value: u8) -> ProblemType {
        match value {
            0 => ProblemType::None,
            1 => ProblemType::Unknown,
            2 => ProblemType::Timeout,
            3 => ProblemType::Memory,
            4 => ProblemType::UndefinedBehavior,
            5 => ProblemType::AssertError,
            6 => ProblemType::UncaughtExceptionError,
            7 => ProblemType::Other,
            8 => ProblemType::Any,
            9 => ProblemType::GoRuntimeError,
            10 => ProblemType::DatabaseCrash,
            11 => ProblemType::LogicError,
            v => {
                log::warn!("Unknown ProblemType value: {}", v);
                ProblemType::Unknown
            }
        }
    }
}

/// 问题状态
#[derive(Clone, Debug, Serialize_repr, Deserialize_repr)]
#[repr(u8)]
pub enum ProblemState {
    Fixed = 0,
    NewDiscovered = 1,
    Repeat = 2,
    Indeterminated = 3,
}

/// 表示一个测出的问题
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TestProblem {
    pub id: TestProblemId,
    pub module_id: ModuleId,
    pub case_id: TestCaseId,
    #[serde(rename = "type")]
    pub problem_type: ProblemType,
    #[serde(default)]
    pub sub_type: String,
    pub state: ProblemState,
    #[serde(default)]
    pub data: String,
}

/// Websocket 收到的消息
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "cmd")]
pub enum WebsocketCommandIn {
    /// 握手响应
    Ready,
    /// 心跳响应
    Pong {
        /// 可能是 RUNNING_STOPPED_BY_REMOTE，服务端要求关闭连接
        data: String,
    },
}

/// Websocket 发送的消息
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "cmd")]
pub enum WebsocketCommandOut {
    /// 心跳请求
    Ping,
    /// 报告问题
    Problem(WebsocketCommandProblem),
    /// 报告用例
    Case(WebsocketCommandCase),
    /// 报告当前运行的 SQL
    #[serde(rename = "sqlCase")]
    SqlCase(WebsocketCommandCase),
    /// 报告已运行的 SQL 数量
    #[serde(rename = "caseCount")]
    CaseCount {
        #[serde(rename = "execsDone")]
        execs_done: u64,
    },
    /// 更新统计信息
    UpdateTest(WebsocketCommandUpdateTest),
    /// 也是更新统计信息
    UpdateTestFuzzer(WebsocketCommandUpdateTestFuzzer),
}

/// 平台要求的调用栈
///
/// 我们会定义自己的类型，然后转换为此类型
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StackFrame {
    /// 二进制文件名
    pub binary: String,
    /// （函数内）偏移量
    /// TODO: 改 usize 再自定义序列化器
    /// TODO: 我们可以加一个绝对偏移量
    pub offset: String,
    /// 源文件名
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub file: String,
    /// 函数名
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub function: String,
    /// 行号
    #[serde(default, skip_serializing_if = "is_zero")]
    pub line: u64,
    /// 列号
    #[serde(default, skip_serializing_if = "is_zero")]
    pub col: u64,
}

/// [`ProblemInfoItem`] 变种：调用栈消息
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ProblemInfoItemStack {
    /// 栈帧列表
    pub stack: Vec<StackFrame>,
    /// 小节标题
    pub title: String,
}

/// [`ProblemInfoItem`] 变种：文本消息
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ProblemInfoItemText {
    /// 内容
    pub content: String,
    /// 小节标题
    pub title: String,
}

/// 提交问题详情的一个小节
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case", tag = "type")]
pub enum ProblemInfoItem {
    /// 调用栈
    Stack(ProblemInfoItemStack),
    /// 文本
    Text(ProblemInfoItemText),
}

/// 提交问题详情的一种（数据库模糊测试使用）
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ProblemInfoAny {
    pub sections: Vec<ProblemInfoItem>,
    pub subtype: String,
    pub title: String,
}

#[derive(Clone, Default, Debug, Serialize, Deserialize)]
pub struct OsProblemInfo {
    pub sections: Vec<ProblemInfoItem>,
    pub subtype: String,
    pub title: String,
    #[serde(rename = "type")]
    pub ty: String,
    #[serde(rename = "secondCaseName")]
    pub second_case_name: String,
    #[serde(rename = "secondCaseHash")]
    pub second_case_hash: String,
}

/// 包管理：描述一个依赖的版本，包括名称和版本号
///
/// 序列化/反序列化成 名称@版本号 的格式
#[derive(Clone, Debug)]
pub struct PackageDependencyVersion {
    pub name: String,
    pub version: String,
}

impl Serialize for PackageDependencyVersion {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        serializer.serialize_str(&format!("{}@{}", self.name, self.version))
    }
}

impl<'de> Deserialize<'de> for PackageDependencyVersion {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        struct PackageDependencyVersionVisitor;

        impl<'de> serde::de::Visitor<'de> for PackageDependencyVersionVisitor {
            type Value = PackageDependencyVersion;

            fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
                formatter.write_str("a string in the format 'name@version'")
            }

            fn visit_str<E: serde::de::Error>(self, value: &str) -> Result<Self::Value, E> {
                // Split the input string into 'name' and 'version' parts
                let parts: Vec<&str> = value.split('@').collect();
                if parts.len() != 2 {
                    return Err(E::custom("Invalid format. Expected 'name@version'."));
                }

                let name = parts[0].to_string();
                let version = parts[1].to_string();

                Ok(PackageDependencyVersion { name, version })
            }
        }

        deserializer.deserialize_str(PackageDependencyVersionVisitor)
    }
}

/// 包管理：包的某个版本的详细信息
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PackageVersionInfo {
    pub version: String,
    /// 依赖列表：可以为空
    #[serde(default)]
    pub dependencies: Vec<PackageDependencyVersion>,
    #[serde(default)]
    pub url: String,
    #[serde(default)]
    pub sha1sum: String,
    #[serde(default)]
    pub size: usize,
}

/// 包管理：包描述，包括名称、描述和版本列表
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Package {
    pub name: String,
    pub description: String,
    pub versions: Vec<PackageVersionInfo>,
}

/// 包管理：包里面 `wfuzz-package.json` 的格式
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LocalPackage {
    pub name: String,
    pub platform: String,
    pub description: String,
    pub version: String,
    pub hash: String,
    /// 依赖列表：可以为空
    #[serde(default)]
    pub dependencies: Vec<PackageDependencyVersion>,
    /// 功能列表：可以为空
    #[serde(default)]
    pub features: Vec<String>,
}

struct VecAsStrSerializer;

impl VecAsStrSerializer {
    fn serialize<S>(v: &Vec<String>, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: Serializer,
    {
        let serialized_array = serde_json::to_string(v)
            .expect("Failed to serialize pretty_display as a string vector");
        serializer.serialize_str(&serialized_array)
    }

    fn deserialize<'de, D>(deserializer: D) -> Result<Vec<String>, D::Error>
    where
        D: Deserializer<'de>,
    {
        let s = String::deserialize(deserializer)?;
        Ok(serde_json::from_str(&s).unwrap_or_default())
    }
}

/// 提交问题详情
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebsocketUploadProblem {
    /// 问题类型
    #[serde(rename = "type")]
    pub problem_type: ProblemType,
    /// 详情
    /// 里面塞一个 [`ProblemInfoAny`] 的序列化结果
    /// TODO: 应该有办法写漂亮（自定义序列化器，但是，麻烦）
    pub data: String,
    /// 导致问题的用例，美化打印过的
    #[serde(with = "VecAsStrSerializer")]
    pub pretty_display: Vec<String>,
}

/// Websocket 发送的消息：报告问题
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebsocketCommandProblem {
    /// sha1 哈希值
    pub hash: String,
    /// 内容，已经过 gzip + base64 编码，如果为 [`None`]，则内容已提前上传
    pub content: Option<String>,
    /// 详细说明
    pub problems: Vec<WebsocketUploadProblem>,
    /// 问题堆栈哈希值
    pub dedup_hash: String,
}

impl WebsocketCommandProblem {
    /// 创建一个新的 [`WebsocketCommandProblem`]，其中 `raw` 为原始数据
    /// 老接口：content 在内上传
    pub fn new(raw: &[u8], problems: Vec<WebsocketUploadProblem>, dedup_input: &[u8]) -> Self {
        Self {
            hash: sha1_hexdigest(raw),
            content: Some(zlib_then_base64(raw)),
            problems,
            dedup_hash: sha1_hexdigest(dedup_input),
        }
    }

    /// 创建一个新的 [`WebsocketCommandProblem`]，其中 `raw` 为原始数据
    /// 新接口：content 另行上传
    pub fn new_skeleton(
        hash: String,
        problems: Vec<WebsocketUploadProblem>,
        dedup_input: &[u8],
    ) -> Self {
        Self {
            hash,
            content: None,
            problems,
            dedup_hash: sha1_hexdigest(dedup_input),
        }
    }
}

/// Websocket 发送的消息：报告用例
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebsocketCommandCase {
    pub hash: String,
    /// 内容，已经过 gzip + base64 编码
    pub content: String,
}

impl WebsocketCommandCase {
    /// 创建一个新的 [`WebsocketCommandCase`]，其中 `raw` 为原始数据
    pub fn new(raw: &[u8]) -> Self {
        Self {
            hash: sha1_hexdigest(raw),
            content: zlib_then_base64(raw),
        }
    }
}

/// Websocket 发送的消息：更新统计信息
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebsocketCommandUpdateTest {
    pub cycles_done: u64,
    pub execs_done: u64,
    pub execs_per_sec: f64,
    pub paths_total: u64,
    #[cfg(any(feature = "virt", feature = "zz"))]
    pub paths_total_coverage: f64,
    #[serde(with = "IntBoolSerializer")]
    pub active: bool,
    pub running: RunningState,
    pub cpu_time: u64,
    /// 测试开始时间： 自 UNIX epoch 以来的时间戳（毫秒）
    pub start_at: u64,
    /// 测试结束时间： 自 UNIX epoch 以来的时间戳（毫秒）
    pub stop_at: u64,
    /// 状态更新时间： 自 UNIX epoch 以来的时间戳（毫秒）
    pub update_at: u64,
    #[serde(skip)]
    /// 崩溃数量，仅本地 UI 展现用
    pub crashes: u64,
}

/// Websocket 发送的消息：更新统计信息（稍微详细）
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WebsocketCommandUpdateTestFuzzer {
    pub index: i32,
    pub fuzzer: String,
    #[serde(flatten)]
    pub update: WebsocketCommandUpdateTest,
}

#[cfg(feature = "os")]
pub use __private::WebsocketStopCallback;
#[allow(unused)]
mod __private {
    pub struct WebsocketStopCallback {
        pub callback: Option<Box<dyn FnOnce() + Send>>,
    }

    impl WebsocketStopCallback {
        pub fn new(callback: impl FnOnce() + Send + 'static) -> Self {
            Self {
                callback: Some(Box::new(callback)),
            }
        }

        pub fn apply(&mut self) {
            self.callback.take().map(|f| f());
        }
    }
}

#[cfg(not(feature = "os"))]
pub use __legacy::WebsocketStopCallback;
#[allow(unused)]
mod __legacy {
    /// Websocket 在收到服务器停止消息时执行的函数
    pub struct WebsocketStopCallback {
        pub callback: Box<dyn FnMut() + Send>,
    }

    impl WebsocketStopCallback {
        pub fn new(callback: impl FnMut() + Send + 'static) -> Self {
            Self {
                callback: Box::new(callback),
            }
        }
    }
}

/// Websocket 的流类型：可选使用 TLS，基于 TCP 的 Websocket 流
pub type WebsocketStream =
    tungstenite::protocol::WebSocket<tungstenite::stream::MaybeTlsStream<std::net::TcpStream>>;
