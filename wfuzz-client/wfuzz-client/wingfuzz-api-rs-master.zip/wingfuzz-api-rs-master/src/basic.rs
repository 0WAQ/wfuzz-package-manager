use std::{
    error,
    fmt::Display,
    io::Read,
};

use serde::{
    Deserialize,
    Serialize,
};
use sha1::Digest;

/// API 错误信息
#[derive(Debug)]
pub enum APIError {
    /// 服务器返回的错误
    ServerError(i32, String),
    /// 鉴权错误（包含 HTTP 401 和 403）
    AuthError(),
    /// HTTP 错误码错误
    HTTPError(reqwest::StatusCode),
    /// 其他 HTTP 错误
    OtherHTTPError(reqwest::Error),
    /// WebSocket 连接错误
    WebSocketError(tungstenite::Error),
}

impl Display for APIError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            APIError::ServerError(code, msg) => {
                write!(f, "Server error (code: {}, message: {})", code, msg)
            }
            APIError::AuthError() => write!(f, "Auth error"),
            APIError::HTTPError(code) => write!(f, "Http error (code: {})", code),
            APIError::OtherHTTPError(e) => write!(f, "Other error ({})", e),
            APIError::WebSocketError(e) => write!(f, "Websocket error ({})", e),
        }
    }
}

impl error::Error for APIError {}

impl From<tungstenite::Error> for APIError {
    /// 方便 ? 操作符自动转换错误
    fn from(e: tungstenite::Error) -> Self {
        Self::WebSocketError(e)
    }
}

impl From<reqwest::Error> for APIError {
    /// 方便 ? 操作符自动转换错误
    fn from(e: reqwest::Error) -> Self {
        match e.status() {
            Some(reqwest::StatusCode::UNAUTHORIZED) | Some(reqwest::StatusCode::FORBIDDEN) => {
                Self::AuthError()
            }
            Some(status) => Self::HTTPError(status),
            None => Self::OtherHTTPError(e),
        }
    }
}

impl From<reqwest::StatusCode> for APIError {
    /// 方便 ? 操作符自动转换错误
    fn from(status: reqwest::StatusCode) -> Self {
        assert!(!status.is_success(), "HTTP status code should not be 2xx");

        match status {
            reqwest::StatusCode::UNAUTHORIZED | reqwest::StatusCode::FORBIDDEN => Self::AuthError(),
            _ => Self::HTTPError(status),
        }
    }
}

/// API 返回的结果类型
pub type APIResult<T> = Result<T, APIError>;

/// 部分响应的通用格式
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CommonResponse<T> {
    pub code: i32,
    #[serde(default)]
    pub message: String,
    pub data: Option<T>,
}

impl<T> CommonResponse<T> {
    /// 构建成功的响应
    pub fn ok(val: T) -> Self {
        Self {
            code: 0,
            message: String::new(),
            data: Some(val),
        }
    }

    /// 构建失败的响应
    pub fn err(code: i32, message: String) -> Self {
        Self {
            code,
            message,
            data: None,
        }
    }
}

/// 序列化器，将布尔值序列化为数字 0 或 1
#[derive(Clone, Debug)]
pub(crate) struct IntBoolSerializer();

impl IntBoolSerializer {
    pub fn serialize<S>(value: &bool, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_i32(if *value { 1 } else { 0 })
    }

    pub fn deserialize<'de, D>(deserializer: D) -> Result<bool, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let value = i32::deserialize(deserializer)?;
        Ok(value != 0)
    }
}

/// 定义 ID 类型
///
/// TODO: 处理宏前面的注释。处理后下面的两斜线注释可改成三斜线注释。
macro_rules! define_id {
    ($(#[$attr:meta])* $name:ident) => {
        $(#[$attr])*
        #[derive(Clone, Copy, Debug, Serialize, Deserialize)]
        pub struct $name(pub i32);

        /// 从 i32 转换，可当作手动构造器
        impl From<i32> for $name {
            fn from(value: i32) -> Self {
                Self(value)
            }
        }

        /// 用于 format，在 URL 中使用
        impl std::fmt::Display for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}", self.0.to_string())
            }
        }

        /// 默认值为 0
        impl Default for $name {
            fn default() -> Self {
                Self(0)
            }
        }
    };
}

define_id!(
    /// 项目 ID
    ProjectId
);

define_id!(
    /// 模块 ID
    ModuleId
);

define_id!(
    /// 测试 ID
    TestId
);

define_id!(
    /// 测试组 ID
    TestGroupId
);

define_id!(
    /// 版本 ID
    VersionId
);

define_id!(
    /// 测试用例 ID
    TestCaseId
);

define_id!(
    /// 测出的问题 ID
    TestProblemId
);

define_id!(
    /// 任务 runner ID
    TaskRunnerId
);

define_id!(
    /// (runner) 测试任务 ID
    FuzzTaskId
);

define_id!(
    /// (runner) 测试任务执行 ID
    ExecutionTaskId
);

define_id!(
    /// (并行测试) 语料 ID
    CorpusId
);

define_id!(
    /// ai测试id
    AiTestId
);

define_id!(
    /// ai测试创建人id
    AiTestCreateId
);

define_id!(
    /// ai测试模型id
    AiTestModelId
);

define_id!(
    /// ai测试数据集id
    AiTestDatasetId
);

#[cfg(feature = "virt")]
pub use dk::*;
#[cfg(feature = "virt")]
mod dk {
    use serde::{
        Deserialize,
        Serialize,
    };
    define_id!(
        /// 虚拟化测试 ID
        VirtTestId
    );

    define_id!(
        /// 虚拟化镜像 ID
        VirtImageId
    );
}

/// 先 zlib 的 deflate 再 base64 编码 (也就是 SDK 中的 "gzipCompress"，其中调用了 zlib 的 deflate 方法)
///
/// ps: 不是 flate2 的 gzip 也不是 flate2 的 deflate（缺 zlib 头），想不到吧
pub(crate) fn zlib_then_base64(input: &[u8]) -> String {
    // log::debug!("deflate_then_base64: input = {:?}", input);
    let mut encoder = flate2::read::ZlibEncoder::new(input, flate2::Compression::default());
    let mut buf: Vec<u8> = vec![];
    encoder.read_to_end(&mut buf).unwrap();
    // log::debug!("deflate_then_base64: buf = {:?}", buf);
    let ret = base64::Engine::encode(&base64::engine::general_purpose::STANDARD, &buf);
    // log::debug!("deflate_then_base64: ret = {}", ret);
    ret
}

/// 是 0 吗 （可用于各种类型判断是否为默认值）
pub(crate) fn is_zero<T: PartialEq + Default>(v: &T) -> bool {
    *v == T::default()
}

/// SHA1
pub(crate) fn sha1_hexdigest(input: &[u8]) -> String {
    let mut hasher = sha1::Sha1::new();
    hasher.update(input);
    hasher
        .finalize()
        .iter()
        .map(|b| format!("{:02x}", b))
        .collect()
}

/// 助手函数，用于将 [`reqwest::blocking::Request`] 格式化为 cURL 命令
pub(crate) struct CurlFormatter<'a> {
    #[cfg(feature = "async")]
    request: &'a reqwest::Request,

    #[cfg(not(feature = "async"))]
    request: &'a reqwest::blocking::Request,
}

impl<'a> CurlFormatter<'a> {
    #[cfg(feature = "async")]
    pub fn new(request: &'a reqwest::Request) -> Self {
        Self { request }
    }

    #[cfg(not(feature = "async"))]
    pub fn new(request: &'a reqwest::blocking::Request) -> Self {
        Self { request }
    }

    /// 打印 HTTP 头
    fn headers(&self) -> String {
        self.request
            .headers()
            .iter()
            .map(|(k, v)| format!("-H '{}: {}'", k, v.to_str().unwrap()))
            .collect::<Vec<String>>()
            .join(" ")
    }

    /// 打印 HTTP 包内容
    fn body(&self) -> String {
        let Some(body) = self.request.body() else {
            return String::new();
        };
        let Some(b) = body.as_bytes() else {
            return String::new();
        };
        if b.len() > 4096 {
            format!("-d <{} bytes of data>", b.len())
        } else {
            format!("-d '{}'", String::from_utf8_lossy(b))
        }
    }
}

impl<'a> Display for CurlFormatter<'a> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "curl -X {} {} {} {}",
            self.request.method(),
            self.request.url(),
            self.headers(),
            self.body()
        )
    }
}
