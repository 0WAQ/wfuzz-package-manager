use super::APIClient;
use crate::{
    basic::APIResult,
    types::{
        OsDownloadSyzlangRequest,
        OsUploadCaseRequest,
        OsUploadProblemRequest,
    },
    OsDownloadCorpusRequest,
};

#[allow(async_fn_in_trait)]
pub trait OsPlatformApiExt {
    async fn os_upload_case(&self, req: OsUploadCaseRequest) -> APIResult<u64>;

    async fn os_upload_problem(&self, req: OsUploadProblemRequest) -> APIResult<Vec<u64>>;

    #[cfg(feature = "dk")]
    async fn os_downlaod_corpus(&self, req: OsDownloadCorpusRequest) -> APIResult<Vec<u8>>;

    #[cfg(feature = "dk")]
    async fn os_download_syzlang(&self, req: OsDownloadSyzlangRequest) -> APIResult<Vec<u8>>;
}

impl OsPlatformApiExt for APIClient {
    async fn os_upload_case(&self, req: OsUploadCaseRequest) -> APIResult<u64> {
        log::debug!("os_upload_case: test_id={}", req.test_id);
        let req = self
            .http_client
            .post(format!(
                "{}/api/regression/os/onUploadCase",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .json(&req)
            .build()
            .expect("Failed to build OsUploadCaseRequest");
        self.emit_infinite_rest(req).await
    }

    async fn os_upload_problem(&self, req: OsUploadProblemRequest) -> APIResult<Vec<u64>> {
        log::debug!("os_upload_problem: test_id={}", req.test_id);
        let req = self
            .http_client
            .post(format!(
                "{}/api/problem/os/onUploadProblem",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .json(&req)
            .build()
            .expect("Failed to build OsUploadProblemRequest");
        self.emit_infinite_rest(req).await
    }

    #[cfg(feature = "dk")]
    async fn os_downlaod_corpus(&self, req: OsDownloadCorpusRequest) -> APIResult<Vec<u8>> {
        log::debug!("os_downlaod_corpus: test_group_id={}", req.test_group_id);
        let test_state = self.get_test(req.test_group_id).await?;
        let hash = match test_state.seed_hash {
            Some(hash) => hash,
            None => self.get_default_corpus_hash().await?,
        };
        self.download_file_v2(&hash, false).await
    }

    #[cfg(feature = "dk")]
    async fn os_download_syzlang(&self, req: OsDownloadSyzlangRequest) -> APIResult<Vec<u8>> {
        use crate::APIError;

        log::debug!("os_download_syzlang: test_group_id={}", req.test_group_id);
        let test_state = self.get_test(req.test_group_id).await?;
        let hash = match test_state.model_hash {
            Some(hash) => hash,
            None => return Err(APIError::ServerError(500, "No model hash".to_string())),
        };
        self.download_file_v2(&hash, false).await
    }
}
