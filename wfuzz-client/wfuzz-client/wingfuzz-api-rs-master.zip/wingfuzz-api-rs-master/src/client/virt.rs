use super::APIClient;
use crate::{
    basic::{
        APIResult,
        TestGroupId,
        VirtImageId,
    },
    types::{
        VirtCreateProblemRequest,
        VirtCreateProblemResponse,
        VirtCreateTestRequest,
        VirtCreateTestResponse,
        VirtDownloadCorpusRequest,
        VirtDownloadSyzlangRequest,
        VirtImageInfo,
        VirtTestGroupInfo,
        VirtUpdateTestRequest,
        VirtUploadCaseFileRequest,
        VirtUploadCaseFileRequestInner,
        VirtUploadCaseFileResponse,
    },
};

#[allow(async_fn_in_trait)]
pub trait VirtPlatformApiExt {
    async fn virt_create_test(
        &self,
        req: VirtCreateTestRequest,
    ) -> APIResult<VirtCreateTestResponse>;

    async fn virt_update_test(&self, req: VirtUpdateTestRequest) -> APIResult<()>;

    async fn virt_upload_case_file(
        &self,
        req: VirtUploadCaseFileRequest,
    ) -> APIResult<VirtUploadCaseFileResponse>;

    async fn virt_create_problem(
        &self,
        req: VirtCreateProblemRequest,
    ) -> APIResult<VirtCreateProblemResponse>;

    async fn virt_get_test_group_info(&self, group_id: TestGroupId)
        -> APIResult<VirtTestGroupInfo>;

    async fn virt_get_image_info(&self, image_id: VirtImageId) -> APIResult<VirtImageInfo>;

    async fn virt_downlaod_corpus(&self, req: VirtDownloadCorpusRequest) -> APIResult<Vec<u8>>;

    async fn virt_download_syzlang(&self, req: VirtDownloadSyzlangRequest) -> APIResult<Vec<u8>>;
}

impl VirtPlatformApiExt for APIClient {
    async fn virt_create_test(
        &self,
        req: VirtCreateTestRequest,
    ) -> APIResult<VirtCreateTestResponse> {
        let req = self
            .http_client
            .post(format!(
                "{}/api/dk/vp/test/createTest",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&req)
            .build()
            .expect("Failed to build virt create test request");
        self.emit_infinite_rest(req).await
    }

    async fn virt_update_test(&self, req: VirtUpdateTestRequest) -> APIResult<()> {
        let req = self
            .http_client
            .put(format!(
                "{}/api/dk/vp/test/updateTest",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&req)
            .build()
            .expect("Failed to build ai update state request");
        let _ = self.send_http_request(req).await?;
        Ok(())
    }

    async fn virt_upload_case_file(
        &self,
        req: VirtUploadCaseFileRequest,
    ) -> APIResult<VirtUploadCaseFileResponse> {
        let file_hash = self
            .upload_file("case", &mut req.file_content.as_slice())
            .await?;

        let upload_req = VirtUploadCaseFileRequestInner {
            test_id: req.test_id,
            file: file_hash,
        };
        let req = self
            .http_client
            .post(format!(
                "{}/api/dk/vp/case/create",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&upload_req)
            .build()?;

        self.emit_infinite_rest(req).await
    }

    async fn virt_create_problem(
        &self,
        req: VirtCreateProblemRequest,
    ) -> APIResult<VirtCreateProblemResponse> {
        let data = serde_json::to_string(&req)
            .expect("Failed to serialize request of creating virt problem");
        let req = self
            .http_client
            .post(format!(
                "{}/api/dk/vp/problem/create",
                self.config.wfuzz_server_endpoint
            ))
            .header("Content-Type", "application/json")
            .bearer_auth(self.config.get_access_token().await)
            .body(data)
            .build()
            .expect("Failed to build virt create problem request");
        self.emit_infinite_rest(req).await
    }

    async fn virt_get_test_group_info(
        &self,
        group_id: TestGroupId,
    ) -> APIResult<VirtTestGroupInfo> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/dk/vp/test/{}",
                self.config.wfuzz_server_endpoint, group_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build virt get test_group info request");
        self.emit_infinite_rest(req).await
    }

    async fn virt_get_image_info(&self, image_id: VirtImageId) -> APIResult<VirtImageInfo> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/dk/vp/image/{}",
                self.config.wfuzz_server_endpoint, image_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build virt get image info request");
        self.emit_infinite_rest(req).await
    }

    async fn virt_downlaod_corpus(&self, req: VirtDownloadCorpusRequest) -> APIResult<Vec<u8>> {
        use crate::APIError;

        log::debug!("virt_downlaod_corpus: test_group_id={}", req.test_group_id);
        let test_state = self.virt_get_test_group_info(req.test_group_id).await?;
        let hash = match test_state.seed_hash {
            Some(hash) => hash,
            None => return Err(APIError::ServerError(500, "No seed hash".to_string())),
        };
        self.download_file_v2(&hash, false).await
    }

    async fn virt_download_syzlang(&self, req: VirtDownloadSyzlangRequest) -> APIResult<Vec<u8>> {
        use crate::APIError;

        log::debug!("virt_download_syzlang: test_group_id={}", req.test_group_id);
        let test_state = self.virt_get_test_group_info(req.test_group_id).await?;
        let hash = match test_state.model_hash {
            Some(hash) => hash,
            None => return Err(APIError::ServerError(500, "No model hash".to_string())),
        };
        self.download_file_v2(&hash, false).await
    }
}
