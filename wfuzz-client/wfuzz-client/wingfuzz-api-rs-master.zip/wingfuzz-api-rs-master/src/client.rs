#[cfg(all(feature = "os", feature = "async"))]
mod os;
#[cfg(all(feature = "virt", feature = "async"))]
mod virt;
#[cfg(feature = "async")]
use std::sync::Arc;
use std::{
    io::Read,
    path,
    time::Duration,
};

#[cfg(all(feature = "os", feature = "async"))]
pub use os::*;
use sha1::Digest;
#[cfg(feature = "async")]
use tokio::{
    io::AsyncWriteExt,
    sync::RwLock,
};
#[cfg(all(feature = "virt", feature = "async"))]
pub use virt::*;

use crate::*;

/// 连接平台的配置
#[derive(Clone)]
struct APIConfig {
    /// `WFUZZ_SERVER`: 服务器地址，形如 <http://dev.xfuzz.shuimuyulin.com:10100>
    pub wfuzz_server_endpoint: String,
    /// `WFUZZ_TOKEN`: OAuth token
    pub oauth_token: String,
    /// Access token，由 OAuth token 生成
    #[cfg(not(feature = "async"))]
    pub access_token: String,
    #[cfg(feature = "async")]
    pub access_token: Arc<RwLock<Option<String>>>,
}

impl APIConfig {
    #[cfg(not(feature = "async"))]
    fn get_access_token(&self) -> String {
        return self.access_token.clone();
    }

    #[cfg(feature = "async")]
    async fn get_access_token(&self) -> String {
        return self
            .access_token
            .read()
            .await
            .clone()
            .expect("Access token is not set");
    }
}

/// 连接平台的 HTTP API 客户端
#[derive(Clone)]
pub struct APIClient {
    config: APIConfig,
    /// HTTP 客户端
    #[cfg(not(feature = "async"))]
    http_client: reqwest::blocking::Client,

    #[cfg(feature = "async")]
    http_client: reqwest::Client,
}

impl APIClient {
    /// 使用传入的 `WFUZZ_SERVER` 和 `WFUZZ_TOKEN`（可选） 创建一个新的 API 客户端
    pub fn new(server: &str, token: &str) -> Self {
        Self {
            config: APIConfig {
                wfuzz_server_endpoint: server.to_string(),
                oauth_token: token.to_string(),
                #[cfg(not(feature = "async"))]
                access_token: Default::default(),

                #[cfg(feature = "async")]
                access_token: Arc::new(RwLock::new(None)),
            },
            #[cfg(not(feature = "async"))]
            http_client: reqwest::blocking::ClientBuilder::new()
                .danger_accept_invalid_certs(true)
                .danger_accept_invalid_hostnames(true)
                .build()
                .expect("Error creating HTTP client"),
            #[cfg(feature = "async")]
            http_client: reqwest::ClientBuilder::new()
                .danger_accept_invalid_certs(true)
                .danger_accept_invalid_hostnames(true)
                .build()
                .expect("Error creating HTTP client"),
        }
    }

    /// 设置 `WFUZZ_SERVER`
    pub fn set_server(&mut self, server: &str) {
        self.config.wfuzz_server_endpoint = server.to_string();
    }

    /// 设置 `WFUZZ_TOKEN`
    pub fn set_token(&mut self, token: &str) {
        self.config.oauth_token = token.to_string();
    }

    /// 建立 Websocket 客户端，并启动心跳
    pub fn create_websocket_client(
        &self,
        test_id: TestId,
        stop_callback: WebsocketStopCallback,
    ) -> APIWebsocketClient {
        APIWebsocketClient::new(
            &self
                .config
                .wfuzz_server_endpoint
                .replace("https://", "wss://")
                .replace("http://", "ws://"),
            &self.config.oauth_token,
            test_id,
            stop_callback,
        )
    }

    /// 获取本机 IPv4 地址
    pub fn get_local_address(&self) -> std::net::Ipv4Addr {
        let ifaces = if_addrs::get_if_addrs().expect("Get local IP address failed");
        for iface in ifaces.iter() {
            if iface.is_loopback() || iface.is_link_local() {
                continue;
            }
            if let if_addrs::IfAddr::V4(addr) = &iface.addr {
                return addr.ip;
            }
        }
        panic!("Cannot find local IP address");
    }

    /// 获取本机主机名
    pub fn get_hostname(&self) -> String {
        gethostname::gethostname().to_string_lossy().to_string()
    }
}

#[cfg(feature = "async")]
impl APIClient {
    async fn send_http_request(&self, req: reqwest::Request) -> reqwest::Result<reqwest::Response> {
        // 打印时转换成 cURL 命令
        log::debug!("Sending HTTP request: {}", CurlFormatter::new(&req));
        let rsp = self.http_client.execute(req).await;
        log::debug!("Received HTTP response: {:?}", rsp);
        rsp
    }

    async fn emit_infinite_rest<T: serde::de::DeserializeOwned + std::fmt::Debug>(
        &self,
        req: reqwest::Request,
    ) -> APIResult<T> {
        loop {
            let req = req.try_clone().expect("Failed to clone http request");
            let rsp = self.send_http_request(req).await;

            match self.process_http_response(rsp).await {
                Ok(d) => return Ok(d),
                Err(e) => {
                    log::warn!("Failed to send request by {:?}, retrying...", e);
                    continue;
                }
            }
        }
    }

    async fn process_http_response<T: serde::de::DeserializeOwned + std::fmt::Debug>(
        &self,
        rsp: reqwest::Result<reqwest::Response>,
    ) -> APIResult<T> {
        let r = rsp?;
        if r.status().is_success() {
            let common_response: CommonResponse<T> =
                r.json().await.expect("Failed to parse common response");
            log::debug!("HTTP response content: {:?}", common_response);

            match common_response.data {
                Some(data) if common_response.code == 0 => Ok(data),
                _ => Err(APIError::ServerError(
                    common_response.code,
                    common_response.message,
                )),
            }
        } else {
            let http_code = r.status();
            log::debug!("HTTP error {}, content: {}", http_code, r.text().await?);

            if let reqwest::StatusCode::UNAUTHORIZED | reqwest::StatusCode::FORBIDDEN = http_code {
                // Login to obtain new access_token
                log::warn!("AuthError, login to update access_token");
                self.login().await?;
                log::debug!("Login success, retry sending request");
            }

            Err(APIError::from(http_code))
        }
    }

    /// 向服务器请求新的 WFUZZ_TOKEN
    pub async fn create_token(&self) -> APIResult<String> {
        let req = self
            .http_client
            .post(format!(
                "{}/client_code/new",
                self.config.wfuzz_server_endpoint
            ))
            .form(&std::collections::HashMap::from([(
                "machine",
                self.get_hostname(),
            )]))
            .build()
            .expect("Failed to build create token request");
        self.emit_infinite_rest(req).await
    }

    /// 检查 WFUZZ_TOKEN 是否有效
    /// - 正常返回 Ok(1)
    /// - 失败返回 Err(ServerError)
    pub async fn check_token(&self, token: &str) -> APIResult<i32> {
        let req = self
            .http_client
            .get(format!(
                "{}/client_code/{}",
                self.config.wfuzz_server_endpoint, token
            ))
            .build()
            .expect("Failed to build check token request");
        self.emit_infinite_rest(req).await
    }

    pub async fn login(&self) -> APIResult<()> {
        let login_request = LoginRequest {
            grant_type: "client_code".to_string(),
            client_id: "client".to_string(),
            code: self.config.oauth_token.clone(),
        };
        log::debug!("login_request: {:?}", login_request);
        let req = self
            .http_client
            .post(format!("{}/oauth/token", self.config.wfuzz_server_endpoint))
            .form(&login_request)
            .build()
            .expect("Failed to build login request");
        let rsp = self.send_http_request(req).await?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }

        let login_response: LoginResponse =
            rsp.json().await.expect("Failed to parse login response");
        log::debug!("login_response: {:?}", login_response);

        // 设置 access_token
        *self.config.access_token.write().await = Some(login_response.access_token.clone());
        Ok(())
    }

    /// 获取当前用户信息
    pub async fn get_current_user(&self) -> APIResult<UserInfoResponse> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/user/current",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build get user request");
        self.emit_infinite_rest(req).await
    }

    /// 包管理：获取包列表
    pub async fn get_repo(&self, platform: &str) -> APIResult<Vec<Package>> {
        let req = self
            .http_client
            .get(format!(
                "{}/repo/{}",
                self.config.wfuzz_server_endpoint, platform
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build get repo request");
        self.emit_infinite_rest(req).await
    }

    /// 包管理：下载包，保存到指定路径，并校验 sha1 及大小
    ///
    /// NOTE: 以流的形式下载文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub async fn download_package(&self, info: &PackageVersionInfo, path: &std::path::PathBuf) {
        let parent_dir = path.parent().expect("Failed to get residing directory");
        std::fs::create_dir_all(parent_dir).expect("Failed to mkdir -p directory");
        {
            let mut file = tokio::fs::File::create(path)
                .await
                .expect("Failed to create file");
            let url = format!("{}{}", self.config.wfuzz_server_endpoint, info.url);
            log::debug!("Downloading package from {}...", url);
            let rsp = self
                .http_client
                .get(&url)
                .bearer_auth(self.config.get_access_token().await)
                .send()
                .await
                .expect("Failed to emit download package request");
            file.write(rsp.bytes().await.unwrap().as_ref())
                .await
                .expect("Write file failed");
            file.sync_all().await.expect("Save file failed");
        } // 这里析构 file，避免之后读的时候出问题
        let mut file = std::fs::File::open(path).expect("Failed to open file");
        let mut hasher = sha1::Sha1::new();
        let file_size =
            std::io::copy(&mut file, &mut hasher).expect("Failed to calculate the hash sum");

        if hasher
            .finalize()
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect::<String>()
            != info.sha1sum
        {
            panic!("SHA-1 mismatch");
        }
        if file_size as usize != info.size {
            panic!("Size mismatch");
        }
    }

    pub async fn create_test(&self, test: CreateTestRequest) -> APIResult<Test> {
        log::debug!("create_test: {:?}", test);
        let req = self
            .http_client
            .post(format!("{}/api/test", self.config.wfuzz_server_endpoint))
            .bearer_auth(self.config.get_access_token().await)
            .form(&test)
            .build()
            .expect("Failed to build create test request");
        self.emit_infinite_rest(req).await
    }

    /// 请求上传覆盖率
    pub async fn test_upload_coverage(&self, test: UploadCoverageRequest) -> APIResult<HashVec> {
        // log::debug!("test upload coverage: {:?}", test.files);
        let req = self
            .http_client
            .post(format!(
                "{}/api/coverage/getCoverage",
                self.config.wfuzz_server_endpoint
            ))
            .timeout(Duration::from_secs(1000)) // 超时时间
            .bearer_auth(self.config.get_access_token().await)
            .json(&test)
            .build()
            .expect("Failed to build create test request");
        let rsp = self.send_http_request(req).await?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }
        let hashes: HashVec = rsp.json().await.expect("Failed to parse login response");
        log::debug!("retrun hash vec is: {:?}", hashes);

        Ok(hashes)
    }

    /// 上传覆盖率内容信息
    pub async fn test_coverage_upload_source(&self, test: CoverageUploadSource) -> APIResult<()> {
        // log::debug!("test coverage upload source : {:?}", test);
        let req = self
            .http_client
            .post(format!(
                "{}/api/coverage/upload-source",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .json(&test)
            .build()
            .expect("Failed to build create test request");
        let rsp = self.send_http_request(req).await?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }
        Ok(())
    }

    /// 创建测试组
    pub async fn create_test_group(&self, req: CreateTestGroupRequest) -> APIResult<TestGroup> {
        log::debug!("create_test_group: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/test/testGroup",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&req)
            .build()
            .expect("Failed to build create group request");
        self.emit_infinite_rest(req).await
    }

    /// (runner) 创建 fuzz task
    pub async fn create_fuzz_task(&self, req: CreateFuzzTaskRequest) -> APIResult<FuzzTaskId> {
        log::debug!("create_fuzz_task: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/fuzzTask/createFuzzTask",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&req)
            .build()
            .expect("Failed to build create fuzz task request");
        self.emit_infinite_rest(req).await
    }

    /// (runner) 创建 fuzz 执行 Task
    pub async fn create_fuzz_execution_task(
        &self,
        req: CreateExecutionTaskRequest,
    ) -> APIResult<ExecutionTaskId> {
        log::debug!("create_execution_task: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/fuzzTask/createExecutionTask",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&req)
            .build()
            .expect("Failed to build create execution task");
        self.emit_infinite_rest(req).await
    }

    /// (runner) 返回当前测试状态
    ///
    /// - test_group_id: 测试组 id
    pub async fn get_test(&self, test_group_id: TestGroupId) -> APIResult<TestState> {
        log::debug!("get_test: test_group_id={}", test_group_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/test/{}",
                self.config.wfuzz_server_endpoint, test_group_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build get test state request");
        self.emit_infinite_rest(req).await
    }

    /// (runner) 获取 fuzz 执行 task 的状态
    pub async fn get_execution_task(
        &self,
        task_id: ExecutionTaskId,
    ) -> APIResult<ExecutionTaskInfo> {
        log::debug!("get_execution_task: {:?}", task_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/fuzzTask/getExecutionTask/{}",
                self.config.wfuzz_server_endpoint, task_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build get cases request");
        self.emit_infinite_rest(req).await
    }

    /// 获取模块中的用例列表
    pub async fn get_cases_of_module(
        &self,
        module_id: ModuleId,
        skip: i32,
        limit: i32,
    ) -> APIResult<Vec<TestCase>> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/case/in-module/{}",
                self.config.wfuzz_server_endpoint, module_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .query(&QueryRange { skip, limit })
            .build()
            .expect("Failed to build get cases request");
        self.emit_infinite_rest(req).await
    }

    /// 获取模块中的问题列表
    pub async fn get_problems_of_module(
        &self,
        module_id: ModuleId,
        skip: i32,
        limit: i32,
    ) -> APIResult<Vec<TestProblem>> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/problem/in-module/{}",
                self.config.wfuzz_server_endpoint, module_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .query(&QueryRange { skip, limit })
            .build()
            .expect("Failed to build get problems request");
        self.emit_infinite_rest(req).await
    }

    pub async fn upload_file(
        &self,
        filename: &str,
        content: &mut dyn std::io::Read,
    ) -> APIResult<String> {
        log::debug!("upload_file: {}", filename);
        let mut buf = Vec::<u8>::new();
        content.read_to_end(&mut buf).expect("Read file failed");
        let req = self
            .http_client
            .post(format!(
                "{}/file/updateFile",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .multipart(
                reqwest::multipart::Form::new().part(
                    "file",
                    reqwest::multipart::Part::bytes(buf)
                        .file_name(filename.to_string())
                        .mime_str("application/octet-stream")
                        .expect("Failed to create multipart form"),
                ),
            )
            .build()
            .expect("Failed to build upload file request");
        let rsp = self.send_http_request(req).await;
        self.process_http_response::<String>(rsp).await
    }

    /// 文件下载, 根据给定文件哈希 `file_hash` 从远程下载文件，并保存到指定 `output` 路径
    ///
    /// NOTE: 以流的形式下载文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub async fn download_file(&self, file_hash: &str, output: &str) {
        let path = path::PathBuf::from(output);

        let parent_dir = path.parent().expect("Failed to get residing directory");
        std::fs::create_dir_all(parent_dir).expect("Failed to create directory");

        let url = format!("{}/file/{}", self.config.wfuzz_server_endpoint, file_hash);
        log::debug!("Downloading package from {}...", url);
        log::debug!("curl -X GET {} --output {}", url, output);

        let rsp = self
            .http_client
            .get(&url)
            .bearer_auth(self.config.get_access_token().await)
            .send()
            .await
            .expect("Failed to emit download package request");

        let mut file = tokio::fs::File::create(path)
            .await
            .expect("Failed to create file");
        let _ = file.write(rsp.bytes().await.unwrap().as_ref()).await;
        file.sync_all().await.expect("Save file failed");
    }

    /// 标记上传文件为用例
    ///
    /// - test_id: 测试 ID
    /// - hash: 文件的哈希值
    /// - created_at: 文件创建时间戳
    /// - is_init_case: 是否是初始用例
    ///
    /// 返回值是？
    pub async fn post_case(
        &self,
        test_id: TestId,
        hash: &str,
        created_at: u64,
        is_init_case: bool,
    ) -> APIResult<u64> {
        log::debug!(
            "post_case: test_id={}, hash={}, created_at={}, is_init_case={}",
            test_id,
            hash,
            created_at,
            is_init_case
        );
        let req = self
            .http_client
            .post(format!(
                "{}/api/case/{}/case",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&{
                PostCaseRequest {
                    hash: hash.to_owned(),
                    created_at,
                    is_init_case,
                }
            })
            .build()
            .expect("Failed to build create test request");
        self.emit_infinite_rest(req).await
    }

    /// (runner) 上传 corpus
    ///
    /// - test_id: 测试 id
    /// - content: 文件内容流，可以是一个 Reader，也可以是 `[u8]`
    ///
    /// 返回值是 corpus id
    pub async fn corpus_upload(
        &self,
        test_id: TestGroupId,
        content: &mut dyn std::io::Read,
    ) -> APIResult<CorpusId> {
        log::debug!("corpus_upload: test_id={}", test_id);

        // 因为sha1_hexdigest是private,所以这里直接读取文件内容,而不从外界获取
        let mut buf = Vec::<u8>::new();
        content.read_to_end(&mut buf).expect("Read file failed");

        // 读取文件内容到字符串
        let hash = sha1_hexdigest(&buf);

        let req = self
            .http_client
            .post(format!(
                "{}/api/corpus/upload/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .query(&[("hash", hash)])
            .multipart(
                reqwest::multipart::Form::new().part(
                    "file",
                    reqwest::multipart::Part::bytes(buf)
                        .file_name("corpus".to_string())
                        .mime_str("application/octet-stream")
                        .expect("Failed to create multipart form"),
                ),
            )
            .build()
            .expect("Failed to build upload corpus request");
        let rsp = self.send_http_request(req).await;
        self.process_http_response::<CorpusId>(rsp).await
    }

    /// (runner) 根据 corpus id 获取内容
    ///
    /// - test_id: 测试组 id
    /// - corpus_id 要查找的corpus id
    ///
    /// 返回 corpus 内容
    ///
    /// NOTE: 以流的形式下载 corpus 文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub async fn corpus_find(
        &self,
        test_id: TestGroupId,
        corpus_id: CorpusId,
    ) -> APIResult<String> {
        log::debug!("corpus_find: test_id={}, corpus_id={}", test_id, corpus_id,);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/find/{}/{}",
                self.config.wfuzz_server_endpoint, test_id, corpus_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build find corpus request");

        let rsp = self
            .send_http_request(req)
            .await
            .expect("Failed to send corpus_find request");
        let content = rsp.bytes().await.expect("Failed to get corpus").to_vec();

        Ok(String::from_utf8(content).expect("Failed to convert byte stream of corpus to string"))
    }

    /// (runner) 取 corpus 的队首（并删除）
    ///
    /// - test_id: 测试组 id
    ///
    /// 返回队首的 corpus 内容
    ///
    /// NOTE: 以流的形式下载 corpus 文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub async fn corpus_get(&self, test_id: TestGroupId) -> APIResult<String> {
        log::debug!("corpus_get: test_id={}", test_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/poll/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build remove corpus request");

        let rsp = self
            .send_http_request(req)
            .await
            .expect("Failed to send corpus_get request");
        let content = rsp.bytes().await.expect("Failed to get corpus").to_vec();

        Ok(String::from_utf8(content).expect("Failed to convert byte stream of corpus to string"))
    }

    /// (runner) 返回当前测试 corpus 的个数
    ///
    /// - test_id: 测试组 id
    pub async fn corpus_count(&self, test_id: TestGroupId) -> APIResult<usize> {
        log::debug!("corpus_count: test_id={}", test_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/count/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build corpus count request");
        self.emit_infinite_rest(req).await
    }

    /// 获取AI测试启动信息
    pub async fn ai_get_test(&self, test_id: TestId) -> APIResult<AiTest> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/ai/test/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build ai get test request");
        self.emit_infinite_rest(req).await
    }

    /// 上传AI测试状态
    pub async fn ai_update_state(&self, test_id: TestId, state: AiTestState) -> APIResult<()> {
        let req = self
            .http_client
            .put(format!(
                "{}/api/ai/test/{}/state-update",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .form(&state)
            .build()
            .expect("Failed to build ai update state request");
        let _ = self.send_http_request(req);
        Ok(())
    }

    /// 上传AI测试结果
    pub async fn ai_upload_result(&self, test_id: TestId, result: String) -> APIResult<()> {
        let req = self
            .http_client
            .post(format!(
                "{}/api/ai/test/{}/data-upload",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .header("Content-Type", "application/json")
            .body(result)
            .build()
            .expect("Failed to build ai upload result request");
        let _ = self.send_http_request(req);
        Ok(())
    }

    /// AI测试心跳
    pub async fn ai_heartbeat(&self, test_id: TestId) -> APIResult<()> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/ai/test/{}/heartbeat",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build ai get test request");
        self.emit_infinite_rest(req).await
    }

    pub async fn cc_upload_driver_meta(
        &self,
        project_id: ProjectId,
        content: String,
    ) -> reqwest::Result<reqwest::Response> {
        let req = self
            .http_client
            .post(format!(
                "{}/api/project/code/updateBuildResult?projectId={}",
                self.config.wfuzz_server_endpoint, project_id
            ))
            .bearer_auth(self.config.get_access_token().await)
            .header("Content-Type", "application/json")
            .body(content)
            .build()
            .expect("Failed to build cc_upload_driver_meta");
        self.send_http_request(req).await
    }

    pub async fn find_case_by_hash(&self, hash: &str) -> APIResult<String> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/case/hash/{}",
                self.config.wfuzz_server_endpoint, hash
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build find case by hash request");
        self.emit_infinite_rest(req).await
    }

    pub async fn download_file_v2(
        &self,
        file_hash: &str,
        zlib_decompress: bool,
    ) -> APIResult<Vec<u8>> {
        log::debug!("download_file_v2: file_hash={}", file_hash);
        let req = self
            .http_client
            .get(format!(
                "{}/file/{}",
                self.config.wfuzz_server_endpoint, file_hash
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build download_file_v2 request");

        let rsp = self
            .send_http_request(req)
            .await
            .expect("Failed to send download_file_v2 request");
        let content = rsp
            .bytes()
            .await
            .expect("Failed to file content from response")
            .to_vec();

        if zlib_decompress {
            // zlib decompress
            let mut decoder = flate2::read::ZlibDecoder::new(&content[..]);
            let mut data = Vec::new();
            decoder
                .read_to_end(&mut data)
                .expect("Failed to decompress content");
            Ok(data)
        } else {
            Ok(content)
        }
    }

    #[cfg(feature = "dk")]
    pub async fn get_default_corpus_hash(&self) -> APIResult<String> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/default-corpus",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token().await)
            .build()
            .expect("Failed to build get_default_corpus_hash request");
        self.emit_infinite_rest(req).await
    }
}

#[cfg(not(feature = "async"))]
impl APIClient {
    /// 发送请求
    fn send_http_request(
        &mut self,
        req: reqwest::blocking::Request,
    ) -> reqwest::Result<reqwest::blocking::Response> {
        // 打印时转换成 cURL 命令
        log::debug!("Sending HTTP request: {}", CurlFormatter::new(&req));
        let rsp = self.http_client.execute(req);
        log::debug!("Received HTTP response: {:?}", rsp);
        rsp
    }

    fn emit_infinite_rest<T: serde::de::DeserializeOwned + std::fmt::Debug>(
        &mut self,
        req: reqwest::blocking::Request,
    ) -> APIResult<T> {
        loop {
            let req = req.try_clone().expect("Failed to clone http request");
            let rsp = self.send_http_request(req);

            match self.process_http_response(rsp) {
                Ok(d) => return Ok(d),
                Err(e) => {
                    log::warn!("Failed to send request by {:?}, retrying...", e);
                    continue;
                }
            }
        }
    }

    /// 将 HTTP 响应转换为 APIResult
    fn process_http_response<T: serde::de::DeserializeOwned + std::fmt::Debug>(
        &mut self,
        rsp: reqwest::Result<reqwest::blocking::Response>,
    ) -> APIResult<T> {
        let r = rsp?;
        if r.status().is_success() {
            let common_response: CommonResponse<T> =
                r.json().expect("Failed to parse common response");
            log::debug!("HTTP response content: {:?}", common_response);

            match common_response.data {
                Some(data) if common_response.code == 0 => Ok(data),
                _ => Err(APIError::ServerError(
                    common_response.code,
                    common_response.message,
                )),
            }
        } else {
            let http_code = r.status();
            log::debug!("HTTP error {}, content: {}", http_code, r.text()?);

            if let reqwest::StatusCode::UNAUTHORIZED | reqwest::StatusCode::FORBIDDEN = http_code {
                // Login to obtain new access_token
                log::warn!("AuthError, login to update access_token");
                self.login()?;
                log::debug!("Login success, retry sending request");
            }

            Err(APIError::from(http_code))
        }
    }

    /// 向服务器请求新的 WFUZZ_TOKEN
    pub fn create_token(&mut self) -> APIResult<String> {
        let req = self
            .http_client
            .post(format!(
                "{}/client_code/new",
                self.config.wfuzz_server_endpoint
            ))
            .form(&std::collections::HashMap::from([(
                "machine",
                self.get_hostname(),
            )]))
            .build()
            .expect("Failed to build create token request");
        self.emit_infinite_rest(req)
    }

    /// 检查 WFUZZ_TOKEN 是否有效
    /// - 正常返回 Ok(1)
    /// - 失败返回 Err(ServerError)
    pub fn check_token(&mut self, token: &str) -> APIResult<i32> {
        let req = self
            .http_client
            .get(format!(
                "{}/client_code/{}",
                self.config.wfuzz_server_endpoint, token
            ))
            .build()
            .expect("Failed to build check token request");
        self.emit_infinite_rest(req)
    }

    /// 检测是否已登录
    pub fn login(&mut self) -> APIResult<()> {
        let login_request = LoginRequest {
            grant_type: "client_code".to_string(),
            client_id: "client".to_string(),
            code: self.config.oauth_token.clone(),
        };
        log::debug!("login_request: {:?}", login_request);
        let req = self
            .http_client
            .post(format!("{}/oauth/token", self.config.wfuzz_server_endpoint))
            .form(&login_request)
            .build()
            .expect("Failed to build login request");
        let rsp = self.send_http_request(req)?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }

        let login_response: LoginResponse = rsp.json().expect("Failed to parse login response");
        log::debug!("login_response: {:?}", login_response);

        // 设置 access_token
        self.config.access_token = login_response.access_token.clone();

        Ok(())
    }

    /// 获取当前用户信息
    pub fn get_current_user(&mut self) -> APIResult<UserInfoResponse> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/user/current",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build get user request");
        self.emit_infinite_rest(req)
    }

    /// 包管理：获取包列表
    pub fn get_repo(&mut self, platform: &str) -> APIResult<Vec<Package>> {
        let req = self
            .http_client
            .get(format!(
                "{}/repo/{}",
                self.config.wfuzz_server_endpoint, platform
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build get repo request");
        self.emit_infinite_rest(req)
    }

    /// 包管理：下载包，保存到指定路径，并校验 sha1 及大小
    ///
    /// NOTE: 以流的形式下载文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub fn download_package(&mut self, info: &PackageVersionInfo, path: &std::path::PathBuf) {
        let parent_dir = path.parent().expect("Failed to get residing directory");
        std::fs::create_dir_all(parent_dir).expect("Failed to mkdir -p directory");
        {
            let mut file = std::fs::File::create(path).expect("Failed to create file");
            let url = format!("{}{}", self.config.wfuzz_server_endpoint, info.url);
            log::debug!("Downloading package from {}...", url);
            let mut rsp = self
                .http_client
                .get(&url)
                .bearer_auth(self.config.get_access_token())
                .send()
                .expect("Failed to emit download package request");
            rsp.copy_to(&mut file).expect("Failed to download package");
            file.sync_all().expect("Save file failed");
        } // 这里析构 file，避免之后读的时候出问题
        let mut file = std::fs::File::open(path).expect("Failed to open file");
        let mut hasher = sha1::Sha1::new();
        let file_size =
            std::io::copy(&mut file, &mut hasher).expect("Failed to calculate the hash sum");

        if hasher
            .finalize()
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect::<String>()
            != info.sha1sum
        {
            panic!("SHA-1 mismatch");
        }
        if file_size as usize != info.size {
            panic!("Size mismatch");
        }
    }

    /// 创建测试
    pub fn create_test(&mut self, test: CreateTestRequest) -> APIResult<Test> {
        log::debug!("create_test: {:?}", test);
        let req = self
            .http_client
            .post(format!("{}/api/test", self.config.wfuzz_server_endpoint))
            .bearer_auth(self.config.get_access_token())
            .form(&test)
            .build()
            .expect("Failed to build create test request");
        self.emit_infinite_rest(req)
    }

    /// 请求上传覆盖率
    pub fn test_upload_coverage(&mut self, test: UploadCoverageRequest) -> APIResult<HashVec> {
        // log::debug!("test upload coverage: {:?}", test.files);
        let req = self
            .http_client
            .post(format!(
                "{}/api/coverage/getCoverage",
                self.config.wfuzz_server_endpoint
            ))
            .timeout(Duration::from_secs(1000)) // 超时时间
            .bearer_auth(self.config.get_access_token())
            .json(&test)
            .build()
            .expect("Failed to build create test request");
        let rsp = self.send_http_request(req)?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }
        let hashes: HashVec = rsp.json().expect("Failed to parse login response");
        log::debug!("retrun hash vec is: {:?}", hashes);

        Ok(hashes)
    }

    /// 上传覆盖率内容信息
    pub fn test_coverage_upload_source(&mut self, test: CoverageUploadSource) -> APIResult<()> {
        // log::debug!("test coverage upload source : {:?}", test);
        let req = self
            .http_client
            .post(format!(
                "{}/api/coverage/upload-source",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .json(&test)
            .build()
            .expect("Failed to build create test request");
        let rsp = self.send_http_request(req)?;
        if rsp.status() != reqwest::StatusCode::OK {
            return Err(APIError::HTTPError(rsp.status()));
        }
        Ok(())
    }

    /// 创建测试组
    pub fn create_test_group(&mut self, req: CreateTestGroupRequest) -> APIResult<TestGroup> {
        log::debug!("create_test_group: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/test/testGroup",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .form(&req)
            .build()
            .expect("Failed to build create group request");
        self.emit_infinite_rest(req)
    }

    /// (runner) 创建 fuzz task
    pub fn create_fuzz_task(&mut self, req: CreateFuzzTaskRequest) -> APIResult<FuzzTaskId> {
        log::debug!("create_fuzz_task: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/fuzzTask/createFuzzTask",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .form(&req)
            .build()
            .expect("Failed to build create fuzz task request");
        self.emit_infinite_rest(req)
    }

    /// (runner) 创建 fuzz 执行 Task
    pub fn create_fuzz_execution_task(
        &mut self,
        req: CreateExecutionTaskRequest,
    ) -> APIResult<ExecutionTaskId> {
        log::debug!("create_execution_task: {:?}", req);
        let req = self
            .http_client
            .post(format!(
                "{}/api/fuzzTask/createExecutionTask",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .form(&req)
            .build()
            .expect("Failed to build create execution task");
        self.emit_infinite_rest(req)
    }

    /// (runner) 返回当前测试状态
    ///
    /// - test_group_id: 测试组 id
    pub fn get_test(&mut self, test_group_id: TestGroupId) -> APIResult<TestState> {
        log::debug!("get_test: test_group_id={}", test_group_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/test/{}",
                self.config.wfuzz_server_endpoint, test_group_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build get test state request");
        self.emit_infinite_rest(req)
    }

    /// (runner) 获取 fuzz 执行 task 的状态
    pub fn get_execution_task(&mut self, task_id: ExecutionTaskId) -> APIResult<ExecutionTaskInfo> {
        log::debug!("get_execution_task: {:?}", task_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/fuzzTask/getExecutionTask/{}",
                self.config.wfuzz_server_endpoint, task_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build get cases request");
        self.emit_infinite_rest(req)
    }

    /// 获取模块中的用例列表
    pub fn get_cases_of_module(
        &mut self,
        module_id: ModuleId,
        skip: i32,
        limit: i32,
    ) -> APIResult<Vec<TestCase>> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/case/in-module/{}",
                self.config.wfuzz_server_endpoint, module_id
            ))
            .bearer_auth(self.config.get_access_token())
            .query(&QueryRange { skip, limit })
            .build()
            .expect("Failed to build get cases request");
        self.emit_infinite_rest(req)
    }

    /// 获取模块中的问题列表
    pub fn get_problems_of_module(
        &mut self,
        module_id: ModuleId,
        skip: i32,
        limit: i32,
    ) -> APIResult<Vec<TestProblem>> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/problem/in-module/{}",
                self.config.wfuzz_server_endpoint, module_id
            ))
            .bearer_auth(self.config.get_access_token())
            .query(&QueryRange { skip, limit })
            .build()
            .expect("Failed to build get problems request");
        self.emit_infinite_rest(req)
    }

    /// 上传文件到服务器
    ///
    /// - filename: 传给服务器的文件名
    /// - content: 文件内容流，可以是一个 Reader，也可以是 `[u8]`
    ///
    /// 返回的是文件的哈希值（作为 ID）
    pub fn upload_file(
        &mut self,
        filename: &str,
        content: &mut dyn std::io::Read,
    ) -> APIResult<String> {
        log::debug!("upload_file: {}", filename);
        let mut buf = Vec::<u8>::new();
        content.read_to_end(&mut buf).expect("Read file failed");
        let req = self
            .http_client
            .post(format!(
                "{}/file/updateFile",
                self.config.wfuzz_server_endpoint
            ))
            .bearer_auth(self.config.get_access_token())
            .multipart(
                reqwest::blocking::multipart::Form::new().part(
                    "file",
                    reqwest::blocking::multipart::Part::bytes(buf)
                        .file_name(filename.to_string())
                        .mime_str("application/octet-stream")
                        .expect("Failed to create multipart form"),
                ),
            )
            .build()
            .expect("Failed to build upload file request");
        let rsp = self.send_http_request(req);
        self.process_http_response::<String>(rsp)
    }

    /// 文件下载, 根据给定文件哈希 `file_hash` 从远程下载文件，并保存到指定 `output` 路径
    ///
    /// NOTE: 以流的形式下载文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub fn download_file(&mut self, file_hash: &str, output: &str) {
        let path = path::PathBuf::from(output);

        let parent_dir = path.parent().expect("Failed to get residing directory");
        std::fs::create_dir_all(parent_dir).expect("Failed to create directory");

        let url = format!("{}/file/{}", self.config.wfuzz_server_endpoint, file_hash);
        log::debug!("Downloading package from {}...", url);
        log::debug!("curl -X GET {} --output {}", url, output);

        let mut rsp = self
            .http_client
            .get(&url)
            .bearer_auth(self.config.get_access_token())
            .send()
            .expect("Failed to emit download package request");

        let mut file = std::fs::File::create(path).expect("Failed to create file");
        rsp.copy_to(&mut file).expect("Failed to download package");
        file.sync_all().expect("Save file failed");
    }

    /// 标记上传文件为用例
    ///
    /// - test_id: 测试 ID
    /// - hash: 文件的哈希值
    /// - created_at: 文件创建时间戳
    /// - is_init_case: 是否是初始用例
    ///
    /// 返回值是？
    pub fn post_case(
        &mut self,
        test_id: TestId,
        hash: &str,
        created_at: u64,
        is_init_case: bool,
    ) -> APIResult<u64> {
        log::debug!(
            "post_case: test_id={}, hash={}, created_at={}, is_init_case={}",
            test_id,
            hash,
            created_at,
            is_init_case
        );
        let req = self
            .http_client
            .post(format!(
                "{}/api/case/{}/case",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .form(&{
                PostCaseRequest {
                    hash: hash.to_owned(),
                    created_at,
                    is_init_case,
                }
            })
            .build()
            .expect("Failed to build create test request");
        self.emit_infinite_rest(req)
    }

    /// (runner) 上传 corpus
    ///
    /// - test_id: 测试 id
    /// - content: 文件内容流，可以是一个 Reader，也可以是 `[u8]`
    ///
    /// 返回值是 corpus id
    pub fn corpus_upload(
        &mut self,
        test_id: TestGroupId,
        content: &mut dyn std::io::Read,
    ) -> APIResult<CorpusId> {
        log::debug!("corpus_upload: test_id={}", test_id);

        // 因为sha1_hexdigest是private,所以这里直接读取文件内容,而不从外界获取
        let mut buf = Vec::<u8>::new();
        content.read_to_end(&mut buf).expect("Read file failed");

        // 读取文件内容到字符串
        let hash = sha1_hexdigest(&buf);

        let req = self
            .http_client
            .post(format!(
                "{}/api/corpus/upload/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .query(&[("hash", hash)])
            .multipart(
                reqwest::blocking::multipart::Form::new().part(
                    "file",
                    reqwest::blocking::multipart::Part::bytes(buf)
                        .file_name("corpus".to_string())
                        .mime_str("application/octet-stream")
                        .expect("Failed to create multipart form"),
                ),
            )
            .build()
            .expect("Failed to build upload corpus request");
        let rsp = self.send_http_request(req);
        self.process_http_response::<CorpusId>(rsp)
    }

    /// (runner) 根据 corpus id 获取内容
    ///
    /// - test_id: 测试组 id
    /// - corpus_id 要查找的corpus id
    ///
    /// 返回 corpus 内容
    ///
    /// NOTE: 以流的形式下载 corpus 文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub fn corpus_find(&mut self, test_id: TestGroupId, corpus_id: CorpusId) -> APIResult<String> {
        log::debug!("corpus_find: test_id={}, corpus_id={}", test_id, corpus_id,);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/find/{}/{}",
                self.config.wfuzz_server_endpoint, test_id, corpus_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build find corpus request");

        let mut rsp = self
            .send_http_request(req)
            .expect("Failed to send corpus_find request");
        let mut content = vec![];
        rsp.copy_to(&mut content).expect("Failed to find corpus");

        Ok(String::from_utf8(content).expect("Failed to convert byte stream of corpus to string"))
    }

    /// (runner) 取 corpus 的队首（并删除）
    ///
    /// - test_id: 测试组 id
    ///
    /// 返回队首的 corpus 内容
    ///
    /// NOTE: 以流的形式下载 corpus 文件，无法作为 [`CommonResponse`] 处理并进行无限重试
    pub fn corpus_get(&mut self, test_id: TestGroupId) -> APIResult<String> {
        log::debug!("corpus_get: test_id={}", test_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/poll/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build remove corpus request");

        let mut rsp = self
            .send_http_request(req)
            .expect("Failed to send corpus_get request");
        let mut content = vec![];
        rsp.copy_to(&mut content).expect("Failed to get corpus");

        Ok(String::from_utf8(content).expect("Failed to convert byte stream of corpus to string"))
    }

    /// (runner) 返回当前测试 corpus 的个数
    ///
    /// - test_id: 测试组 id
    pub fn corpus_count(&mut self, test_id: TestGroupId) -> APIResult<usize> {
        log::debug!("corpus_count: test_id={}", test_id);
        let req = self
            .http_client
            .get(format!(
                "{}/api/corpus/count/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build corpus count request");
        self.emit_infinite_rest(req)
    }

    /// 获取AI测试启动信息
    pub fn ai_get_test(&mut self, test_id: TestId) -> APIResult<AiTest> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/ai/test/{}",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build ai get test request");
        self.emit_infinite_rest(req)
    }

    /// 上传AI测试状态
    pub fn ai_update_state(&mut self, test_id: TestId, state: AiTestState) -> APIResult<()> {
        let req = self
            .http_client
            .put(format!(
                "{}/api/ai/test/{}/state-update",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .form(&state)
            .build()
            .expect("Failed to build ai update state request");
        let _ = self.send_http_request(req);
        Ok(())
    }

    /// 上传AI测试结果
    pub fn ai_upload_result(&mut self, test_id: TestId, result: String) -> APIResult<()> {
        let req = self
            .http_client
            .post(format!(
                "{}/api/ai/test/{}/data-upload",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .header("Content-Type", "application/json")
            .body(result)
            .build()
            .expect("Failed to build ai upload result request");
        let _ = self.send_http_request(req);
        Ok(())
    }

    /// AI测试心跳
    pub fn ai_heartbeat(&mut self, test_id: TestId) -> APIResult<()> {
        let req = self
            .http_client
            .get(format!(
                "{}/api/ai/test/{}/heartbeat",
                self.config.wfuzz_server_endpoint, test_id
            ))
            .bearer_auth(self.config.get_access_token())
            .build()
            .expect("Failed to build ai get test request");
        self.emit_infinite_rest(req)
    }

    pub fn cc_upload_driver_meta(
        &mut self,
        project_id: ProjectId,
        content: String,
    ) -> reqwest::Result<reqwest::blocking::Response> {
        let req = self
            .http_client
            .post(format!(
                "{}/api/project/code/updateBuildResult?projectId={}",
                self.config.wfuzz_server_endpoint, project_id
            ))
            .bearer_auth(self.config.get_access_token())
            .header("Content-Type", "application/json")
            .body(content)
            .build()
            .expect("Failed to build cc_upload_driver_meta");
        self.send_http_request(req)
    }
}

/// WFuzz Websocket 客户端
///
/// 使用 SDK 的思想，将 Websocket 客户端的收发消息分离到不同的线程中，避免加锁
pub struct APIWebsocketClient {
    /// 待发消息队列，发送给 [`APIWebsocketClientWorker`] 所在线程
    queue: std::sync::mpsc::Sender<WebsocketCommandOut>,
}

// 给 [`WebsocketStream`] 添加的辅助方法，方便使用
trait APIWebsocketExt {
    /// 获取 Websocket 新连接并进行握手，会无限尝试
    fn connect(url: &str) -> Self;

    /// 实际接收 Websocket 消息
    fn receive_websocket_message_once(&mut self) -> APIResult<WebsocketCommandIn>;

    /// 实际发送 Websocket 消息
    fn send_websocket_message_once(&mut self, msg: WebsocketCommandOut) -> APIResult<()>;

    /// 执行平台规定的握手协议，在连接未断开的情况下会无限重试
    fn handshake(&mut self) -> APIResult<()>;
}

impl APIWebsocketExt for WebsocketStream {
    /// 获取 Websocket 新连接并进行握手，会无限尝试
    fn connect(url: &str) -> WebsocketStream {
        log::debug!("Connecting to Websocket endpoint {}", url);
        loop {
            // 建立新连接
            match tungstenite::connect(url) {
                Ok((mut websocket_client, res)) => {
                    log::debug!(
                        "Connected to Websocket endpoint {:?} {} {:?}",
                        res.version(),
                        res.status(),
                        res.body()
                    );
                    // 设置 TCP 连接为非阻塞模式
                    let stream = match websocket_client.get_mut() {
                        tungstenite::stream::MaybeTlsStream::Plain(s) => s,
                        tungstenite::stream::MaybeTlsStream::NativeTls(s) => s.get_mut(),
                        _ => unimplemented!(),
                    };
                    stream
                        .set_nonblocking(true)
                        .expect("Set non-blocking socket failed");

                    match websocket_client.handshake() {
                        // 成功则返回
                        Ok(()) => return websocket_client,
                        Err(e) => {
                            log::warn!("Handshake failed: {:?}", e);
                        }
                    }
                }
                Err(e) => {
                    log::warn!("Connect to websocket server failed: {}", e);
                }
            }
            // 失败则无限重试（等待 1s）
            std::thread::sleep(std::time::Duration::from_secs(1));
        }
    }

    /// 实际接收 Websocket 消息
    fn receive_websocket_message_once(&mut self) -> APIResult<WebsocketCommandIn> {
        // 在这里 match 会死锁，所以在内部作用域赋值
        let msg = self.read()?;
        let msg = msg.to_text().expect("Websocket message is not text!");
        // 一旦消息为空，我们认为 Websocket 实质性已关闭
        log::debug!("Received websocket message: {}", msg);
        match serde_json::from_str::<WebsocketCommandIn>(msg) {
            Ok(r) => Ok(r),
            Err(e) => {
                log::debug!("Received malformed websocket message: {}. ", msg);
                log::debug!("Websocket may be closed? Error: {}", e);
                Err(APIError::WebSocketError(tungstenite::Error::AlreadyClosed))
            }
        }
    }

    /// 实际发送 Websocket 消息
    fn send_websocket_message_once(&mut self, msg: WebsocketCommandOut) -> APIResult<()> {
        let msg = serde_json::to_string(&msg).expect("Failed to serialize message");
        log::debug!(
            "Sending websocket message: {}",
            if msg.len() < 1024 {
                msg.to_owned()
            } else {
                format!("{} <total {} bytes>", &msg[0..1024], msg.len())
            }
        );
        Ok(self.send(tungstenite::Message::Text(msg.clone()))?)
    }

    /// 执行平台规定的握手协议，在连接未断开的情况下会无限重试
    fn handshake(&mut self) -> APIResult<()> {
        loop {
            match self.receive_websocket_message_once() {
                // 接受了首次握手响应后
                Ok(WebsocketCommandIn::Ready) => {
                    // 心跳正常
                    return Ok(());
                }
                Ok(_) => panic!("Unexpected Websocket response"),
                Err(APIError::WebSocketError(tungstenite::Error::Io(e))) => {
                    // 非阻塞模式下，如果没有消息，会返回 WouldBlock 错误
                    if e.kind() == std::io::ErrorKind::WouldBlock {
                        // 平台此时还没来得及发送握手包
                        std::thread::sleep(std::time::Duration::from_millis(10));
                        continue;
                    } else {
                        // 其他 Websocket 的 IO 错误，返回错误
                        log::warn!("Failed to receive handshake message: {:?}", e);
                        return Err(APIError::WebSocketError(tungstenite::Error::Io(e)));
                    }
                }
                // 其他 Websocket 错误，返回错误
                Err(e) => {
                    log::warn!("Failed to receive handshake message: {:?}", e);
                    return Err(e);
                }
            }
        }
    }
}

/// 负责实际的 Websocket 消息收发，在子线程中运行
struct APIWebsocketClientWorker {
    /// Websocket URL
    url: String,
    /// 实际的 Websocket 客户端
    inner: WebsocketStream,
    /// 待发消息队列，从 [`APIWebsocketClient`] 所在线程接收
    queue: std::sync::mpsc::Receiver<WebsocketCommandOut>,
    /// 接收到停止消息后，执行的回调
    stop_callback: WebsocketStopCallback,
}

impl APIWebsocketClientWorker {
    /// 连接到 Websocket 服务端，接受 ready 消息后返回
    /// 调用者需要启动新线程来启动心跳
    pub fn new(
        url: &str,
        queue: std::sync::mpsc::Receiver<WebsocketCommandOut>,
        stop_callback: WebsocketStopCallback,
    ) -> Self {
        let url = String::from(url);
        let inner = WebsocketStream::connect(&url);
        Self {
            url,
            inner,
            queue,
            stop_callback,
        }
    }

    /// 重新连接 Websocket
    fn reconnect(&mut self) {
        log::debug!("Reconnecting to websocket");
        // 先尝试关闭
        let _ = self.inner.close(None);
        // 再建立新连接
        self.inner = WebsocketStream::connect(&self.url);
    }

    /// 带无限重试发送 Websocket 消息
    fn send_websocket_message(&mut self, msg: WebsocketCommandOut) {
        loop {
            match self.inner.send_websocket_message_once(msg.clone()) {
                Ok(()) => return,
                Err(APIError::WebSocketError(tungstenite::Error::Io(e))) => {
                    // 非阻塞模式下，如果 tcp socket 阻塞，会返回 WouldBlock 错误
                    if e.kind() == std::io::ErrorKind::WouldBlock {
                        std::thread::sleep(std::time::Duration::from_millis(10));
                        // 重试即可
                        continue;
                    } else {
                        // 其他 Websocket 的 IO 错误，重连
                        log::warn!("Failed to receive websocket message: {:?}", e);
                        self.reconnect();
                    }
                }
                // 缓冲区满
                Err(APIError::WebSocketError(tungstenite::Error::WriteBufferFull(e))) => {
                    log::warn!("Failed to send websocket message: {:?}", e);
                    std::thread::sleep(std::time::Duration::from_millis(10));
                    // 重试即可
                    continue;
                }
                Err(APIError::WebSocketError(tungstenite::Error::Capacity(e))) => {
                    panic!("Failed to send websocket message: {:?}", e);
                }
                Err(e) => {
                    log::warn!("Failed to send websocket message: {:?}", e);
                    self.reconnect();
                }
            }
        }
    }

    /// 带无限重试接收 Websocket 消息，如果接收到 [`None`] 则暂无新消息
    fn receive_websocket_message(&mut self) -> Option<WebsocketCommandIn> {
        loop {
            match self.inner.receive_websocket_message_once() {
                Err(APIError::WebSocketError(tungstenite::Error::Io(e))) => {
                    if e.kind() == std::io::ErrorKind::WouldBlock {
                        // 非阻塞模式下，如果没有消息，会返回 WouldBlock 错误
                        return None;
                    } else {
                        // 其他 Websocket 的 IO 错误，重连
                        log::warn!("Failed to receive websocket message: {:?}", e);
                        self.reconnect();
                    }
                }
                Err(e) => {
                    // 其他错误，重连
                    log::warn!("Failed to receive websocket message: {:?}", e);
                    self.reconnect();
                }
                Ok(r) => return Some(r),
            }
        }
    }

    /// 启动消息收发循环
    pub fn start_loop(&mut self) {
        let heartbeat_interval = std::time::Duration::from_secs(5);
        // 上次心跳时间
        let mut last_heartbeat = std::time::Instant::now() - 2 * heartbeat_interval;
        // 见函数结尾
        let mut should_sleep;

        loop {
            should_sleep = true;
            let now = std::time::Instant::now();
            if self.inner.can_write() && now.duration_since(last_heartbeat) >= heartbeat_interval {
                // 心跳，失败即重连
                should_sleep = false;
                self.send_websocket_message(WebsocketCommandOut::Ping);
                last_heartbeat = now;
            }

            // 处理所有待收消息
            loop {
                // 接受消息，失败即重连
                match self.receive_websocket_message() {
                    Some(WebsocketCommandIn::Pong { data }) => {
                        should_sleep = false;
                        if data == "RUNNING_STOPPED_BY_REMOTE" {
                            #[cfg(feature = "os")]
                            {
                                self.stop_callback.apply();
                                break;
                            }
                            #[cfg(not(feature = "os"))]
                            {
                                // 此时停止 fuzzing
                                (self.stop_callback.callback)();
                                std::process::exit(0);
                            }
                        }
                    }
                    Some(_) => log::debug!("Unknown Websocket response"),
                    None => break,
                }
            }

            // 处理所有待发消息
            while self.inner.can_write() {
                match self.queue.try_recv() {
                    Ok(msg) => {
                        should_sleep = false;
                        // 发送消息，失败则重连
                        self.send_websocket_message(msg.clone());
                    }
                    Err(std::sync::mpsc::TryRecvError::Empty) => break,
                    Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                        // 通道已关闭，退出
                        return;
                    }
                }
            }
            if should_sleep {
                // 如果本轮循环没有任何读写操作，则休息 10ms，避免 CPU 占用过高
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
        }
    }
}

impl APIWebsocketClient {
    /// 连接到 Websocket 服务端，并启动心跳
    pub fn new(
        ws_endpoint: &str,
        oauth_token: &str,
        test_id: TestId,
        stop_callback: WebsocketStopCallback,
    ) -> Self {
        // TODO: 只有UI测试的domain是interactiveTest
        let url = format!(
            "{}/ws?clientCode={}&testId={}&clientType=client&domain=defaultTest",
            ws_endpoint, oauth_token, test_id
        );
        // 创建线程通信管道
        let (tx, rx) = std::sync::mpsc::channel::<WebsocketCommandOut>();
        // 创建实际 Websocket 对象
        let mut worker = APIWebsocketClientWorker::new(&url, rx, stop_callback);
        // 启动心跳线程
        std::thread::Builder::new()
            .name("wfuzz-api-heartbeat".to_string())
            .spawn(move || worker.start_loop())
            .expect("Start heartbeat failed");
        Self { queue: tx }
    }

    /// 发送 Websocket 消息
    ///
    /// 内部实现：放入队列后发送
    pub fn send_websocket_message(&self, msg: WebsocketCommandOut) {
        if let Err(e) = self.queue.send(msg) {
            panic!("Failed to send message to websocket thread: {:?}", e);
        }
    }
}
