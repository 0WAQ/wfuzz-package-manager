//! # WFuzz 平台 API 客户端
//!
//! 本模块将 WFuzz 平台的 API 封装成 Rust 的数据结构和函数，方便使用。
//!
//! ## 使用流程
//!
//! 1. 创建 [`APIClient`] 连接到 REST 接口
//! 2. 使用 [`APIClient::login`] 登录（建议使用 WFUZZ_SERVER 和 WFUZZ_TOKEN，启动器会设置这些环境变量），如果登录失败则需要用户使用启动器 `wfuzz login` 命令登录
//! 3. 使用 [`APIClient::create_test`] 创建新测试 ID
//! 4. 调用 [`APIClient`] 相应方法调用平台接口
//! 5. 使用 [`APIClient::create_websocket_client`] 创建 [`APIWebsocketClient`] 连接到 WebSocket 接口
//! 6. 发送 WebSocket 消息需要使用 [`APIWebsocketClient::send_websocket_message`]
//!
//! ## 开发流程（添加新的 API）
//! ### 在 [`APIClient`] 中添加新的 REST 方法
//! 参考 [`APIClient::create_test`]
//! 1. 在 [`types`] 添加新的数据结构（如果必要）
//! 2. 如果涉及到新的 ID 类型，建议在 [`basic`] 中使用 [`basic::define_id`] 宏定义新的 ID 类型，参考 [`basic::ModuleId`]
//! 3. 在 [`client`] 添加新的方法
//!
//! ### 在 [`APIWebsocketClient`] 中添加新的 WebSocket 消息
//! 在 [`WebsocketCommandIn`] （传入消息）或 [`WebsocketCommandOut`] （传出消息）添加新的变种

/// 基本数据结构
pub mod basic;
pub use basic::*;

/// 请求相关的数据结构
pub mod types;
pub use types::*;

/// API 客户端
pub mod client;
pub use client::*;

/// TUI 界面
pub mod tui;
pub use crate::tui::*;
