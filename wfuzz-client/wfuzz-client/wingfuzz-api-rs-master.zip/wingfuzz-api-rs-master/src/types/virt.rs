use serde::{
    Deserialize,
    Serialize,
};

use super::{
    number_to_task_state,
    task_state_to_number,
    ProblemType,
    TaskState,
};
use crate::basic::{
    TestCaseId,
    TestGroupId,
    TestProblemId,
    VirtImageId,
    VirtTestId,
};

/// POST /api/dk/vp/test/createTest 的请求数据
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtCreateTestRequest {
    pub test_group_id: TestGroupId,
    pub node_id: String,
}

impl VirtCreateTestRequest {
    pub fn new(test_group_id: TestGroupId, node_id: String) -> Self {
        Self {
            test_group_id,
            node_id,
        }
    }
}

/// POST /api/dk/vp/test/createTest 的返回数据
#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtCreateTestResponse {
    #[serde(rename = "id")]
    pub test_id: VirtTestId,
    pub image_id: VirtImageId,
    pub test_group_id: TestGroupId,
    pub node_id: String,
    pub execs_done: i64,
    pub execs_per_sec: i64,
    pub paths_total: i64,
    #[serde(deserialize_with = "number_to_task_state")]
    pub state: TaskState,
    pub start_at: u64,
    pub owner_id: String,
    pub create_by: i64,
    pub create_at: u64,
    pub update_at: u64,
    pub delete_at: u64,
}

/// POST /api/dk/vp/test/updateTest 的请求数据
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtUpdateTestRequest {
    pub test_group_id: TestGroupId,
    pub test_id: VirtTestId,
    pub execs_done: i64,
    pub execs_per_sec: i64,
    pub paths_total: i64,
    /// Percentage of coverage
    pub paths_total_coverage: f64,
    #[serde(serialize_with = "task_state_to_number")]
    pub state: TaskState,
}

impl VirtUpdateTestRequest {
    pub fn new(
        test_group_id: TestGroupId,
        test_id: VirtTestId,
        execs_done: i64,
        execs_per_sec: i64,
        paths_total: i64,
        paths_total_coverage: f64,
        state: TaskState,
    ) -> Self {
        Self {
            test_group_id,
            test_id,
            execs_done,
            execs_per_sec,
            paths_total,
            paths_total_coverage,
            state,
        }
    }
}

pub struct VirtUploadCaseFileRequest {
    pub test_id: VirtTestId,
    pub file_content: Vec<u8>,
}

impl VirtUploadCaseFileRequest {
    pub fn new(test_id: VirtTestId, file_content: Vec<u8>) -> Self {
        Self {
            test_id,
            file_content,
        }
    }
}

/// POST /api/dk/vp/case/create 的请求数据
#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub(crate) struct VirtUploadCaseFileRequestInner {
    pub(crate) test_id: VirtTestId,
    pub(crate) file: String,
}

/// POST /api/dk/vp/case/create 的返回数据
#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtUploadCaseFileResponse {
    #[serde(rename = "id")]
    pub case_id: TestCaseId,
    pub image_id: VirtImageId,
    pub test_group_id: TestGroupId,
    pub test_id: VirtTestId,
    #[serde(rename = "file")]
    pub file_hash: String,

    pub create_by: i32,
    pub create_at: u64,
    pub update_at: u64,
    pub delete_at: u64,
    pub owner_id: String,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtCreateProblemRequest {
    pub case_id: TestCaseId,
    #[serde(rename = "type")]
    pub ty: ProblemType,
    pub sub_type: String,
    pub data: String,
}

impl VirtCreateProblemRequest {
    pub fn new(case_id: TestCaseId, ty: ProblemType, sub_type: String, data: String) -> Self {
        Self {
            case_id,
            ty,
            sub_type,
            data,
        }
    }
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtCreateProblemResponse {
    #[serde(rename = "id")]
    pub problem_id: TestProblemId,
    pub image_id: VirtImageId,
    pub test_group_id: TestGroupId,
    pub test_id: VirtTestId,
    pub case_id: TestCaseId,
    pub test_type: String,
    pub pretty_display: String,
    pub case_id_for_display: TestCaseId,
    #[serde(rename = "type")]
    pub ty: ProblemType,
    pub sub_type: String,
    pub data: String,

    pub tag: String,
    pub create_by: i32,
    pub create_at: u64,
    pub update_at: u64,
    pub delete_at: u64,
    pub owner_id: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtTestGroupInfo {
    pub id: TestGroupId,
    pub image_id: VirtImageId,
    pub test_type: String,
    pub test_time: u64,
    pub config: String,
    #[serde(deserialize_with = "number_to_task_state")]
    pub state: TaskState,
    pub start_at: u64,
    pub owner_id: String,
    pub create_by: i64,
    pub create_at: u64,
    pub update_at: u64,
    pub delete_at: u64,
    pub seed_hash: Option<String>,
    pub model_hash: Option<String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtImageInfo {
    pub id: VirtImageId,
    pub name: String,
    pub arch: String,
    #[serde(rename = "type")]
    pub ty: String,
    pub pathname: String,
    pub hash: String,
    pub owner_id: String,
    pub create_by: i64,
    pub create_at: Option<u64>,
    pub update_at: Option<u64>,
    pub delete_at: Option<u64>,
}

/// 虚拟化设备默认种子文件下载
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtDownloadCorpusRequest {
    pub test_group_id: TestGroupId,
}

impl VirtDownloadCorpusRequest {
    pub fn new(test_group_id: TestGroupId) -> Self {
        Self { test_group_id }
    }
}

/// 虚拟化设备默认构建下载
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VirtDownloadSyzlangRequest {
    pub test_group_id: TestGroupId,
}

impl VirtDownloadSyzlangRequest {
    pub fn new(test_group_id: TestGroupId) -> Self {
        Self { test_group_id }
    }
}
