use serde::{
    Deserialize,
    Serialize,
};

use super::WebsocketUploadProblem;
use crate::{
    basic::{
        sha1_hexdigest,
        zlib_then_base64,
        TestId,
    },
    TestGroupId,
};

/// 内核测试用例上传
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OsUploadCaseRequest {
    pub test_id: TestId,
    pub hash: String,
    pub content: String,
    pub dedup_hash: String,
}

impl OsUploadCaseRequest {
    pub fn new(test_id: TestId, raw: &[u8]) -> Self {
        Self {
            test_id,
            hash: sha1_hexdigest(raw),
            content: zlib_then_base64(raw),
            dedup_hash: sha1_hexdigest(raw),
        }
    }
}

/// 内核测试问题上报
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OsUploadProblemRequest {
    pub test_id: TestId,
    /// sha1 哈希值
    pub hash: String,
    /// 内容，已经过 gzip + base64 编码，如果为 [`None`]，则内容已提前上传
    pub content: String,
    /// 详细说明
    pub problems: Vec<WebsocketUploadProblem>,
    /// 问题堆栈哈希值
    pub dedup_hash: String,
}

impl OsUploadProblemRequest {
    pub fn new(
        test_id: TestId,
        raw: &[u8],
        problems: Vec<WebsocketUploadProblem>,
        dedup_input: &[u8],
    ) -> Self {
        Self {
            test_id,
            hash: sha1_hexdigest(raw),
            content: zlib_then_base64(raw),
            problems,
            dedup_hash: sha1_hexdigest(dedup_input),
        }
    }
}

/// 内核默认种子文件下载
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OsDownloadCorpusRequest {
    pub test_group_id: TestGroupId,
}

impl OsDownloadCorpusRequest {
    pub fn new(test_group_id: TestGroupId) -> Self {
        Self { test_group_id }
    }
}

/// 内核默认构建下载
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OsDownloadSyzlangRequest {
    pub test_group_id: TestGroupId,
}

impl OsDownloadSyzlangRequest {
    pub fn new(test_group_id: TestGroupId) -> Self {
        Self { test_group_id }
    }
}
