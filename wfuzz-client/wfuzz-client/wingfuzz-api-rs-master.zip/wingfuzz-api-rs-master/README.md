# 基于阻塞 Rust 的平台 API 封装

## 简介

包含了启动器和数据库测试需要的 API，以及和 SDK 一致的 TUI 界面

## 依赖

- Rust

Ubuntu 安装步骤
```bash
# 安装 Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

## 编译

```bash
cargo build
```

## 运行示例程序

```
# 如果需要调试日志开启此环境变量
WFUZZ_LOG_LEVEL=DEBUG cargo run
```

程序的主入口为 `src/main.rs`。

### API 文档

可以在项目根目录执行以下命令生成 Rustdoc 文档

```bash
cargo doc --all-features --document-private-items --no-deps
```

## 加入到已有项目

在 `Cargo.toml` 中添加以下内容

```toml
[dependencies]
wingfuzz-api = { git = "ssh://git@dev.shuimuyulin.com/xfuzz/wingfuzz-api-rs.git", optional = true }
# 如果使用了 TUI，还需要添加以下依赖
tui-logger = "0.9.2"
```

## 更新本依赖

如果更新了本 repo，需在使用的项目中更新依赖：

```bash
cargo update -p wingfuzz-api
```

## 相关背景知识
### [Rust 语言](https://www.rust-lang.org/)

本项目中使用的 Rust 语言特性均由可在 TRPL 中找到。

- [the Rust Programming Language](https://doc.rust-lang.org/book/)：Rust 官方教程
- 中译本实体书[《Rust 权威指南》](https://item.jd.com/12878638.html) 已出版。
- 中文版电子书[《Rust 程序设计语言》](https://kaisery.github.io/trpl-zh-cn/)，但是不一定是最新的
- [Rust by Example](https://doc.rust-lang.org/rust-by-example/)：通过例子学习 Rust
- [Rustlings](https://github.com/rust-lang/rustlings)：Rust 官方的练习项目，通过对代码改错、填空的方式学习 Rust
